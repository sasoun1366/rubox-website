CREATE TABLE `gallery_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`titleFa` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`url` text NOT NULL,
	`fileKey` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gallery_images_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `site_content` (
	`id` int NOT NULL,
	`heroTitleFa` text NOT NULL,
	`heroTitleEn` text NOT NULL,
	`heroTextFa` text NOT NULL,
	`heroTextEn` text NOT NULL,
	`heroImageUrl` text NOT NULL,
	`heroImageKey` varchar(255),
	`ctaLabelFa` varchar(120) NOT NULL,
	`ctaLabelEn` varchar(120) NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_content_id` PRIMARY KEY(`id`)
);
