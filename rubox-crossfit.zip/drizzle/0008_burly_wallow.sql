ALTER TABLE `blog_articles` ADD `metaTitleFa` varchar(220);--> statement-breakpoint
ALTER TABLE `blog_articles` ADD `metaDescriptionFa` text;--> statement-breakpoint
ALTER TABLE `blog_articles` ADD `keywordsFa` text;--> statement-breakpoint
ALTER TABLE `blog_articles` ADD `keywordsEn` text;