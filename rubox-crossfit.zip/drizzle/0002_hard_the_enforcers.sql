CREATE TABLE `timetable_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entityType` enum('branch','coach') NOT NULL,
	`entityId` int NOT NULL,
	`dayFa` varchar(40) NOT NULL,
	`dayEn` varchar(40) NOT NULL,
	`time` varchar(20) NOT NULL,
	`titleFa` varchar(180) NOT NULL,
	`titleEn` varchar(180) NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `timetable_entries_id` PRIMARY KEY(`id`)
);
