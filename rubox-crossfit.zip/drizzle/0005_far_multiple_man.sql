CREATE TABLE `panel_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`panelUserId` int NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `panel_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `panel_sessions_tokenHash_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `panel_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(80) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`displayName` varchar(160) NOT NULL,
	`permissions` text NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp,
	CONSTRAINT `panel_users_id` PRIMARY KEY(`id`),
	CONSTRAINT `panel_users_username_unique` UNIQUE(`username`)
);
