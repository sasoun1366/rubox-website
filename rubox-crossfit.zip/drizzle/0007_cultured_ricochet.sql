CREATE TABLE `page_view_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`path` varchar(255) NOT NULL,
	`referrer` text,
	`source` varchar(40) NOT NULL,
	`device` varchar(20) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `page_view_events_id` PRIMARY KEY(`id`)
);
