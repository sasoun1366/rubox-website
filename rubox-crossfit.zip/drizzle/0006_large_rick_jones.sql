CREATE TABLE `panel_activity_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`panelUserId` int,
	`actorLabel` varchar(180) NOT NULL,
	`action` varchar(80) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` int,
	`summary` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `panel_activity_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `panel_users` ADD `forcePasswordChange` int DEFAULT 1 NOT NULL;