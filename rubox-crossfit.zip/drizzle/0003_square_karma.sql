CREATE TABLE `blog_articles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(180) NOT NULL,
	`titleFa` varchar(220) NOT NULL,
	`titleEn` varchar(220) NOT NULL,
	`excerptFa` text NOT NULL,
	`excerptEn` text NOT NULL,
	`bodyFa` text NOT NULL,
	`bodyEn` text NOT NULL,
	`category` varchar(100) NOT NULL,
	`readTime` int NOT NULL DEFAULT 5,
	`coverImageUrl` text,
	`published` int NOT NULL DEFAULT 1,
	`publishedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `blog_articles_id` PRIMARY KEY(`id`),
	CONSTRAINT `blog_articles_slug_unique` UNIQUE(`slug`)
);
