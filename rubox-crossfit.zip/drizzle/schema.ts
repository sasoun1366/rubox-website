import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing Manus OAuth. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const panelUsers = mysqlTable("panel_users", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 80 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  displayName: varchar("displayName", { length: 160 }).notNull(),
  permissions: text("permissions").notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn"),
  forcePasswordChange: int("forcePasswordChange").default(1).notNull(),
});

export const panelSessions = mysqlTable("panel_sessions", {
  id: int("id").autoincrement().primaryKey(),
  panelUserId: int("panelUserId").notNull(),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const panelActivityLogs = mysqlTable("panel_activity_logs", {
  id: int("id").autoincrement().primaryKey(),
  panelUserId: int("panelUserId"),
  actorLabel: varchar("actorLabel", { length: 180 }).notNull(),
  action: varchar("action", { length: 80 }).notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  entityId: int("entityId"),
  summary: text("summary").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const siteContent = mysqlTable("site_content", {
  id: int("id").primaryKey(),
  heroTitleFa: text("heroTitleFa").notNull(),
  heroTitleEn: text("heroTitleEn").notNull(),
  heroTextFa: text("heroTextFa").notNull(),
  heroTextEn: text("heroTextEn").notNull(),
  heroImageUrl: text("heroImageUrl").notNull(),
  heroImageKey: varchar("heroImageKey", { length: 255 }),
  ctaLabelFa: varchar("ctaLabelFa", { length: 120 }).notNull(),
  ctaLabelEn: varchar("ctaLabelEn", { length: 120 }).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const galleryImages = mysqlTable("gallery_images", {
  id: int("id").autoincrement().primaryKey(),
  titleFa: varchar("titleFa", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  url: text("url").notNull(),
  fileKey: varchar("fileKey", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const pageViewEvents = mysqlTable("page_view_events", {
  id: int("id").autoincrement().primaryKey(),
  path: varchar("path", { length: 255 }).notNull(),
  referrer: text("referrer"),
  source: varchar("source", { length: 40 }).notNull(),
  device: varchar("device", { length: 20 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const timetableEntries = mysqlTable("timetable_entries", {
  id: int("id").autoincrement().primaryKey(),
  entityType: mysqlEnum("entityType", ["branch", "coach"]).notNull(),
  entityId: int("entityId").notNull(),
  dayFa: varchar("dayFa", { length: 40 }).notNull(),
  dayEn: varchar("dayEn", { length: 40 }).notNull(),
  time: varchar("time", { length: 20 }).notNull(),
  titleFa: varchar("titleFa", { length: 180 }).notNull(),
  titleEn: varchar("titleEn", { length: 180 }).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const blogArticles = mysqlTable("blog_articles", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 180 }).notNull().unique(),
  titleFa: varchar("titleFa", { length: 220 }).notNull(),
  titleEn: varchar("titleEn", { length: 220 }).notNull(),
  excerptFa: text("excerptFa").notNull(),
  excerptEn: text("excerptEn").notNull(),
  metaTitleFa: varchar("metaTitleFa", { length: 220 }),
  metaDescriptionFa: text("metaDescriptionFa"),
  keywordsFa: text("keywordsFa"),
  keywordsEn: text("keywordsEn"),
  bodyFa: text("bodyFa").notNull(),
  bodyEn: text("bodyEn").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  readTime: int("readTime").default(5).notNull(),
  coverImageUrl: text("coverImageUrl"),
  published: int("published").default(1).notNull(),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const coaches = mysqlTable("coaches", {
  id: int("id").autoincrement().primaryKey(),
  nameFa: varchar("nameFa", { length: 180 }).notNull(),
  nameEn: varchar("nameEn", { length: 180 }).notNull(),
  roleFa: varchar("roleFa", { length: 180 }).notNull(),
  roleEn: varchar("roleEn", { length: 180 }).notNull(),
  bioFa: text("bioFa").notNull(),
  bioEn: text("bioEn").notNull(),
  experience: varchar("experience", { length: 40 }).notNull(),
  classesFa: text("classesFa").notNull(),
  classesEn: text("classesEn").notNull(),
  diagramFa: text("diagramFa").notNull(),
  diagramEn: text("diagramEn").notNull(),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 255 }),
  published: int("published").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const branches = mysqlTable("branches", {
  id: int("id").autoincrement().primaryKey(),
  nameFa: varchar("nameFa", { length: 180 }).notNull(),
  nameEn: varchar("nameEn", { length: 180 }).notNull(),
  addressFa: text("addressFa").notNull(),
  addressEn: text("addressEn").notNull(),
  phone: varchar("phone", { length: 60 }).notNull(),
  tagFa: varchar("tagFa", { length: 120 }).notNull(),
  tagEn: varchar("tagEn", { length: 120 }).notNull(),
  mapsUrl: text("mapsUrl"),
  descriptionFa: text("descriptionFa").notNull(),
  descriptionEn: text("descriptionEn").notNull(),
  imageUrl: text("imageUrl"),
  imageKey: varchar("imageKey", { length: 255 }),
  published: int("published").default(1).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type PanelUser = typeof panelUsers.$inferSelect;
export type InsertPanelUser = typeof panelUsers.$inferInsert;
export type PanelActivityLog = typeof panelActivityLogs.$inferSelect;
export type PageViewEvent = typeof pageViewEvents.$inferSelect;
export type SiteContent = typeof siteContent.$inferSelect;
export type InsertSiteContent = typeof siteContent.$inferInsert;
export type GalleryImage = typeof galleryImages.$inferSelect;
export type InsertGalleryImage = typeof galleryImages.$inferInsert;
export type TimetableEntry = typeof timetableEntries.$inferSelect;
export type InsertTimetableEntry = typeof timetableEntries.$inferInsert;
export type BlogArticle = typeof blogArticles.$inferSelect;
export type InsertBlogArticle = typeof blogArticles.$inferInsert;
export type Coach = typeof coaches.$inferSelect;
export type InsertCoach = typeof coaches.$inferInsert;
export type Branch = typeof branches.$inferSelect;
export type InsertBranch = typeof branches.$inferInsert;
