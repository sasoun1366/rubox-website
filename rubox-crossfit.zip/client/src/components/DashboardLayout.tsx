import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { BarChart3, BookOpen, CalendarDays, FilePenLine, Image, LayoutDashboard, LockKeyhole, LogOut, Menu, PanelLeft, Settings2, Users } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { trpc } from "@/lib/trpc";

const menuGroups = [
  { label: "نمای کلی", items: [{ icon: LayoutDashboard, label: "داشبورد", anchor: "overview" }, { icon: BarChart3, label: "محتوای هدر", anchor: "hero" }] },
  { label: "مدیریت محتوا", items: [{ icon: BookOpen, label: "مقالات و مجله", anchor: "blog-editor" }, { icon: Image, label: "کتابخانه تصاویر", anchor: "media" }] },
  { label: "باشگاه ROWBOX", items: [{ icon: Users, label: "مربی‌ها و شعب", anchor: "entities" }, { icon: CalendarDays, label: "تایم‌تیبل کلاس‌ها", anchor: "timetable" }, { icon: Settings2, label: "کاربران و دسترسی‌ها", anchor: "users" }, { icon: FilePenLine, label: "تاریخچه فعالیت", anchor: "activity" }] },
];
const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 264;
const MIN_WIDTH = 220;
const MAX_WIDTH = 360;

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  const panelAuth = trpc.panelAuth.me.useQuery();
  const panelUser = panelAuth.data;
  useEffect(() => { localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString()); }, [sidebarWidth]);
  if (loading || panelAuth.isLoading) return <DashboardLayoutSkeleton />;
  if (!user && !panelUser) return <PanelLogin />;
  if (panelUser?.forcePasswordChange) return <ForcePasswordChange displayName={panelUser.displayName} />;
  return <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}


function PanelLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const login = trpc.panelAuth.login.useMutation({ onSuccess: () => { window.location.reload(); }, onError: (err) => setError(err.message) });
  return <div dir="rtl" className="flex min-h-screen items-center justify-center bg-[#f4f4f2] p-5"><div className="w-full max-w-md rounded-3xl bg-white p-7 shadow-xl"><div className="flex flex-col items-center gap-3 text-center"><img src="/manus-storage/IMG_0856_e6f555ba.PNG" alt="ROWBOX" className="h-12 w-auto brightness-0" /><p className="text-xs font-bold tracking-[.18em] text-black/35">CONTROL ROOM</p><h1 className="text-2xl font-black">ورود کاربران پنل</h1><p className="text-sm text-black/50">با حساب سازمانی خود وارد مدیریت روباکس شوید.</p></div><div className="mt-7 space-y-4"><label className="field-label">نام کاربری<Input dir="ltr" value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" /></label><label className="field-label">رمز عبور<Input dir="ltr" type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" /></label>{error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs font-bold text-red-700">{error}</p>}<Button onClick={() => login.mutate({ username, password })} disabled={login.isPending || !username || !password} className="h-12 w-full rounded-xl bg-black font-bold hover:bg-black/80">{login.isPending ? "در حال ورود..." : "ورود به پنل"}</Button></div><button onClick={() => startLogin()} className="mt-5 w-full text-center text-xs font-bold text-black/45 hover:text-black">ورود مالک پروژه با حساب Google</button></div></div>;
}

function ForcePasswordChange({ displayName }: { displayName: string }) {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState("");
  const change = trpc.panelAuth.changePassword.useMutation({ onSuccess: () => window.location.reload(), onError: err => setError(err.message) });
  return <div dir="rtl" className="flex min-h-screen items-center justify-center bg-[#f4f4f2] p-5"><div className="w-full max-w-md rounded-3xl bg-white p-7 shadow-xl"><div className="flex flex-col items-center gap-3 text-center"><LockKeyhole size={30} /><p className="text-xs font-bold tracking-[.18em] text-black/35">SECURITY CHECK</p><h1 className="text-2xl font-black">رمز عبورت را تغییر بده</h1><p className="text-sm leading-6 text-black/50">سلام {displayName}؛ برای ورود به پنل باید رمز اولیه را تغییر بدهی.</p></div><div className="mt-7 space-y-4"><label className="field-label">رمز فعلی<Input dir="ltr" type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} autoComplete="current-password" /></label><label className="field-label">رمز جدید، حداقل ۸ کاراکتر<Input dir="ltr" type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} autoComplete="new-password" /></label>{error && <p className="rounded-xl bg-red-50 px-3 py-2 text-xs font-bold text-red-700">{error}</p>}<Button onClick={() => change.mutate({ currentPassword, newPassword })} disabled={change.isPending || !currentPassword || newPassword.length < 8} className="h-12 w-full rounded-xl bg-black font-bold hover:bg-black/80">{change.isPending ? "در حال ذخیره..." : "تغییر رمز و ورود به پنل"}</Button></div></div></div>;
}

type DashboardLayoutContentProps = { children: React.ReactNode; setSidebarWidth: (width: number) => void };
function DashboardLayoutContent({ children, setSidebarWidth }: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const panelAuth = trpc.panelAuth.me.useQuery();
  const panelUser = panelAuth.data;
  const panelLogout = trpc.panelAuth.logout.useMutation({ onSuccess: () => panelAuth.refetch() });
  const can = (permission: string) => !panelUser || panelUser.permissions.includes(permission as (typeof panelUser.permissions)[number]);
  const handleLogout = () => panelUser ? panelLogout.mutate() : logout();
  const [location] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  useEffect(() => { if (isCollapsed) setIsResizing(false); }, [isCollapsed]);
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => { if (!isResizing) return; const right = window.innerWidth - (sidebarRef.current?.getBoundingClientRect().right ?? window.innerWidth); const width = right - e.clientX; if (width >= MIN_WIDTH && width <= MAX_WIDTH) setSidebarWidth(width); };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) { document.addEventListener("mousemove", handleMouseMove); document.addEventListener("mouseup", handleMouseUp); document.body.style.cursor = "col-resize"; document.body.style.userSelect = "none"; }
    return () => { document.removeEventListener("mousemove", handleMouseMove); document.removeEventListener("mouseup", handleMouseUp); document.body.style.cursor = ""; document.body.style.userSelect = ""; };
  }, [isResizing, setSidebarWidth]);
  const scrollTo = (anchor: string) => document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "start" });
  return <><div className="relative" ref={sidebarRef}><Sidebar side="right" collapsible="icon" className="border-l-0" disableTransition={isResizing}><SidebarHeader className="h-[76px] justify-center border-b border-white/10"><div className="flex w-full items-center gap-3 px-3"><button onClick={toggleSidebar} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 transition hover:bg-white/15" aria-label="باز و بسته کردن منو"><PanelLeft className="h-4 w-4 text-white" /></button>{!isCollapsed && <div className="flex min-w-0 items-center gap-3"><img src="/manus-storage/IMG_0856_e6f555ba.PNG" alt="ROWBOX" className="h-7 w-auto brightness-0 invert" /><div className="min-w-0"><p className="truncate text-xs font-black tracking-[.18em] text-white">ROWBOX</p><p className="mt-1 text-[10px] text-white/45">CONTROL CENTER</p></div></div>}</div></SidebarHeader><SidebarContent className="gap-0 px-2 py-5">{menuGroups.map(group => <div key={group.label} className="mb-5"><p className="mb-2 px-3 text-[10px] font-bold tracking-[.16em] text-white/35 group-data-[collapsible=icon]:hidden">{group.label}</p><SidebarMenu>{group.items.filter(item => { const permission = item.anchor === "hero" ? "content" : item.anchor === "blog-editor" ? "blog" : item.anchor; return item.anchor === "entities" ? (can("coaches") || can("branches")) : can(permission); }).map(item => <SidebarMenuItem key={item.anchor + item.label}><SidebarMenuButton isActive={location === "/admin" && item.anchor === "overview"} onClick={() => scrollTo(item.anchor)} tooltip={item.label} className="h-11 gap-3 rounded-xl px-3 text-sm font-bold text-white/65 transition hover:bg-white/10 hover:text-white data-[active=true]:bg-white data-[active=true]:text-black"><item.icon className="h-[17px] w-[17px] shrink-0" /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem>)}</SidebarMenu></div>)}</SidebarContent><SidebarFooter className="border-t border-white/10 p-3"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-xl px-1 py-2 text-right transition hover:bg-white/10 group-data-[collapsible=icon]:justify-center"><Avatar className="h-9 w-9 shrink-0 border border-white/15"><AvatarFallback className="bg-white/10 text-xs font-bold text-white">{user?.name?.charAt(0).toUpperCase()}</AvatarFallback></Avatar><div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden"><p className="truncate text-xs font-bold text-white">{user?.name || panelUser?.displayName || "مدیر ROWBOX"}</p><p className="mt-1 truncate text-[10px] text-white/45">{user?.email || (panelUser ? `@${panelUser.username}` : "")}</p></div><Settings2 className="h-4 w-4 text-white/40 group-data-[collapsible=icon]:hidden" /></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-48"><DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="mr-2 h-4 w-4" /><span>خروج از حساب</span></DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter></Sidebar><div className={`absolute left-0 top-0 h-full w-1 cursor-col-resize hover:bg-white/30 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => !isCollapsed && setIsResizing(true)} style={{ zIndex: 50 }} /></div><SidebarInset className="bg-[#f4f4f2]"><header className="sticky top-0 z-40 flex h-[76px] items-center justify-between border-b border-black/5 bg-[#f4f4f2]/90 px-4 backdrop-blur-xl md:px-8"><div className="flex items-center gap-3"><div className="hidden h-9 w-9 items-center justify-center rounded-xl bg-black text-white sm:flex"><Menu className="h-4 w-4" /></div><div><p className="text-[10px] font-bold tracking-[.18em] text-black/35">ROWBOX / CONTROL ROOM</p><p className="mt-1 text-sm font-black">مدیریت باشگاه</p></div></div><div className="flex items-center gap-3"><span className="hidden items-center gap-2 rounded-full bg-white px-3 py-2 text-[11px] font-bold text-black/55 shadow-sm sm:flex"><span className="h-2 w-2 rounded-full bg-emerald-500" /> سیستم آنلاین</span>{isMobile && <SidebarTrigger className="h-9 w-9 rounded-xl bg-black text-white" />}</div></header><main className="flex-1 p-3 sm:p-5 md:p-8">{children}</main></SidebarInset></>;
}
