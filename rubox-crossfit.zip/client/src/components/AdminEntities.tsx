import { useState } from "react";
import { Check, ImagePlus, Loader2, Pencil, Plus, Trash2, UploadCloud, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";

const emptyCoach = { nameFa: "", nameEn: "", roleFa: "", roleEn: "", bioFa: "", bioEn: "", experience: "", classesFa: "", classesEn: "", diagramFa: "", diagramEn: "", imageUrl: "", imageKey: "", published: 1, sortOrder: 0 };
const emptyBranch = { nameFa: "", nameEn: "", addressFa: "", addressEn: "", phone: "", tagFa: "", tagEn: "", mapsUrl: "", descriptionFa: "", descriptionEn: "", imageUrl: "", imageKey: "", published: 1, sortOrder: 0 };

type CoachForm = typeof emptyCoach;
type BranchForm = typeof emptyBranch;

function readDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function uploadEntityImage(file: File) {
  const data = await readDataUrl(file);
  const response = await fetch("/api/admin/upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileName: file.name, contentType: file.type, data }) });
  if (!response.ok) throw new Error("آپلود تصویر انجام نشد");
  return response.json() as Promise<{ url: string; key: string }>;
}

export default function AdminEntities() {
  const [kind, setKind] = useState<"coach" | "branch">("coach");
  const [coachForm, setCoachForm] = useState<CoachForm>(emptyCoach);
  const [branchForm, setBranchForm] = useState<BranchForm>(emptyBranch);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);
  const [notice, setNotice] = useState("");
  const coaches = trpc.site.coaches.managementList.useQuery();
  const branches = trpc.site.branches.managementList.useQuery();
  const utils = trpc.useUtils();
  const createCoach = trpc.site.coaches.create.useMutation({ onSuccess: () => { utils.site.coaches.managementList.invalidate(); reset(); setNotice("پروفایل مربی ذخیره شد."); } });
  const updateCoach = trpc.site.coaches.update.useMutation({ onSuccess: () => { utils.site.coaches.managementList.invalidate(); reset(); setNotice("پروفایل مربی به‌روزرسانی شد."); } });
  const removeCoach = trpc.site.coaches.remove.useMutation({ onSuccess: () => { utils.site.coaches.managementList.invalidate(); setNotice("مربی حذف شد."); } });
  const createBranch = trpc.site.branches.create.useMutation({ onSuccess: () => { utils.site.branches.managementList.invalidate(); reset(); setNotice("شعبه جدید ذخیره شد."); } });
  const updateBranch = trpc.site.branches.update.useMutation({ onSuccess: () => { utils.site.branches.managementList.invalidate(); reset(); setNotice("مشخصات شعبه به‌روزرسانی شد."); } });
  const removeBranch = trpc.site.branches.remove.useMutation({ onSuccess: () => { utils.site.branches.managementList.invalidate(); setNotice("شعبه حذف شد."); } });

  function reset() { setEditingId(null); setCoachForm(emptyCoach); setBranchForm(emptyBranch); }
  function switchKind(next: "coach" | "branch") { setKind(next); reset(); setNotice(""); }
  async function uploadImage(file: File | undefined) {
    if (!file) return;
    setUploading(true);
    try {
      const result = await uploadEntityImage(file);
      if (kind === "coach") setCoachForm(current => ({ ...current, imageUrl: result.url, imageKey: result.key }));
      else setBranchForm(current => ({ ...current, imageUrl: result.url, imageKey: result.key }));
      setNotice("تصویر آپلود شد؛ برای ثبت نهایی ذخیره را بزنید.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "آپلود تصویر ناموفق بود."); }
    finally { setUploading(false); }
  }
  function editCoach(item: NonNullable<typeof coaches.data>[number]) { setKind("coach"); setEditingId(item.id); setCoachForm({ ...item, imageUrl: item.imageUrl ?? "", imageKey: item.imageKey ?? "" }); }
  function editBranch(item: NonNullable<typeof branches.data>[number]) { setKind("branch"); setEditingId(item.id); setBranchForm({ ...item, mapsUrl: item.mapsUrl ?? "", imageUrl: item.imageUrl ?? "", imageKey: item.imageKey ?? "" }); }
  async function save() {
    try {
      if (kind === "coach") { const data = { ...coachForm, imageUrl: coachForm.imageUrl || null, imageKey: coachForm.imageKey || null }; if (editingId) await updateCoach.mutateAsync({ id: editingId, data }); else await createCoach.mutateAsync(data); }
      else { const data = { ...branchForm, mapsUrl: branchForm.mapsUrl || null, imageUrl: branchForm.imageUrl || null, imageKey: branchForm.imageKey || null }; if (editingId) await updateBranch.mutateAsync({ id: editingId, data }); else await createBranch.mutateAsync(data); }
    } catch (error) { setNotice(error instanceof Error ? error.message : "ذخیره‌سازی ناموفق بود."); }
  }
  const saving = createCoach.isPending || updateCoach.isPending || createBranch.isPending || updateBranch.isPending;
  const coachField = (key: keyof CoachForm, value: string | number) => setCoachForm(current => ({ ...current, [key]: value }));
  const branchField = (key: keyof BranchForm, value: string | number) => setBranchForm(current => ({ ...current, [key]: value }));

  return <section id="entities" className="admin-entity-panel mt-7"><div className="flex flex-col justify-between gap-5 border-b border-black/8 pb-6 lg:flex-row lg:items-end"><div><p className="admin-eyebrow">ROSTER / LOCATIONS</p><h2 className="mt-2 text-2xl font-black">مربی‌ها و شعبه‌ها</h2><p className="mt-2 text-sm text-black/50">پروفایل، تصویر، مشخصات و دیاگرام هر مربی یا شعبه را از همین‌جا مدیریت کن.</p></div><div className="flex rounded-xl bg-[#f0f0ed] p-1"><button type="button" onClick={() => switchKind("coach")} className={`rounded-lg px-4 py-2 text-xs font-bold transition ${kind === "coach" ? "bg-black text-white shadow-sm" : "text-black/55"}`}>مربی‌ها</button><button type="button" onClick={() => switchKind("branch")} className={`rounded-lg px-4 py-2 text-xs font-bold transition ${kind === "branch" ? "bg-black text-white shadow-sm" : "text-black/55"}`}>شعبه‌ها</button></div></div>{notice && <div className="mt-5 flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-3 text-xs font-bold text-emerald-700"><Check size={15} />{notice}</div>}<div className="mt-6 grid gap-6 xl:grid-cols-[.72fr_1.28fr]"><div className="rounded-2xl bg-[#f7f7f5] p-4"><div className="mb-4 flex items-center justify-between"><span className="admin-eyebrow">{kind === "coach" ? "COACH LIST" : "BRANCH LIST"}</span><button type="button" onClick={reset} className="rounded-lg p-2 text-black/45 transition hover:bg-white hover:text-black" aria-label="افزودن جدید"><Plus size={17} /></button></div><div className="space-y-2">{kind === "coach" ? (coaches.data ?? []).map(item => <div key={item.id} className={`flex items-center gap-3 rounded-xl border p-3 transition ${editingId === item.id ? "border-black bg-white" : "border-black/7 bg-white/60"}`}><div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-black/10">{item.imageUrl ? <img src={item.imageUrl} alt={item.nameFa} className="h-full w-full object-cover" /> : <ImagePlus className="m-3 h-5 w-5 text-black/35" />}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-black">{item.nameFa}</p><p className="truncate text-[11px] text-black/45">{item.roleFa}</p></div><button type="button" onClick={() => editCoach(item)} className="rounded-lg p-2 text-black/45 hover:bg-black hover:text-white" aria-label="ویرایش"><Pencil size={15} /></button><button type="button" onClick={() => { if (window.confirm("این مربی حذف شود؟")) removeCoach.mutate({ id: item.id }); }} className="rounded-lg p-2 text-black/35 hover:bg-red-600 hover:text-white" aria-label="حذف"><Trash2 size={15} /></button></div>) : (branches.data ?? []).map(item => <div key={item.id} className={`flex items-center gap-3 rounded-xl border p-3 transition ${editingId === item.id ? "border-black bg-white" : "border-black/7 bg-white/60"}`}><div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-black/10">{item.imageUrl ? <img src={item.imageUrl} alt={item.nameFa} className="h-full w-full object-cover" /> : <ImagePlus className="m-3 h-5 w-5 text-black/35" />}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-black">{item.nameFa}</p><p className="truncate text-[11px] text-black/45">{item.addressFa}</p></div><button type="button" onClick={() => editBranch(item)} className="rounded-lg p-2 text-black/45 hover:bg-black hover:text-white" aria-label="ویرایش"><Pencil size={15} /></button><button type="button" onClick={() => { if (window.confirm("این شعبه حذف شود؟")) removeBranch.mutate({ id: item.id }); }} className="rounded-lg p-2 text-black/35 hover:bg-red-600 hover:text-white" aria-label="حذف"><Trash2 size={15} /></button></div>)}{((kind === "coach" ? coaches.data : branches.data)?.length ?? 0) === 0 && <div className="rounded-xl border border-dashed border-black/15 p-6 text-center text-sm text-black/45">هنوز موردی ثبت نشده؛ از فرم کناری شروع کن.</div>}</div></div><div className="rounded-2xl border border-black/8 bg-white p-5"><div className="mb-5 flex items-center justify-between"><div><p className="admin-eyebrow">{editingId ? "EDIT PROFILE" : "NEW PROFILE"}</p><h3 className="mt-1 text-lg font-black">{kind === "coach" ? (editingId ? "ویرایش پروفایل مربی" : "افزودن مربی") : (editingId ? "ویرایش مشخصات شعبه" : "افزودن شعبه")}</h3></div>{editingId && <button type="button" onClick={reset} className="rounded-lg p-2 text-black/35 hover:bg-black/5" aria-label="بستن ویرایش"><X size={17} /></button>}</div>{kind === "coach" ? <CoachForm form={coachForm} field={coachField} imageUploading={uploading} onUpload={uploadImage} /> : <BranchForm form={branchForm} field={branchField} imageUploading={uploading} onUpload={uploadImage} />}<div className="mt-6 flex flex-col justify-between gap-3 border-t border-black/8 pt-5 sm:flex-row sm:items-center"><label className="flex items-center gap-2 text-xs font-bold"><input type="checkbox" checked={(kind === "coach" ? coachForm.published : branchForm.published) === 1} onChange={e => kind === "coach" ? coachField("published", e.target.checked ? 1 : 0) : branchField("published", e.target.checked ? 1 : 0)} /> نمایش در سایت عمومی</label><Button type="button" onClick={save} disabled={saving || uploading} className="h-11 rounded-xl bg-black px-6 text-sm font-bold hover:bg-black/80">{saving ? <Loader2 className="animate-spin" /> : editingId ? "ذخیره تغییرات" : "افزودن به سایت"}</Button></div></div></div></section>;
}

function ImagePicker({ url, uploading, onUpload }: { url: string; uploading: boolean; onUpload: (file: File | undefined) => void }) { return <div className="field-label"><span>تصویر پروفایل / شعبه</span><label className="mt-2 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-black/15 bg-[#f7f7f5] px-4 py-3 text-xs font-bold transition hover:border-black/50"><UploadCloud size={16} />{uploading ? "در حال آپلود..." : url ? "انتخاب تصویر جدید" : "آپلود تصویر از دستگاه"}<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" disabled={uploading} onChange={e => onUpload(e.target.files?.[0])} /></label>{url && <img src={url} alt="پیش‌نمایش" className="mt-3 h-36 w-full rounded-xl object-cover" />}</div>; }

function CoachForm({ form, field, imageUploading, onUpload }: { form: CoachForm; field: (key: keyof CoachForm, value: string | number) => void; imageUploading: boolean; onUpload: (file: File | undefined) => void }) { return <div className="grid gap-4 md:grid-cols-2"><label className="field-label">نام فارسی<Input value={form.nameFa} onChange={e => field("nameFa", e.target.value)} /></label><label className="field-label">English name<Input dir="ltr" value={form.nameEn} onChange={e => field("nameEn", e.target.value)} /></label><label className="field-label">تخصص فارسی<Input value={form.roleFa} onChange={e => field("roleFa", e.target.value)} /></label><label className="field-label">English role<Input dir="ltr" value={form.roleEn} onChange={e => field("roleEn", e.target.value)} /></label><label className="field-label">سابقه<Input value={form.experience} onChange={e => field("experience", e.target.value)} placeholder="۸ سال" /></label><ImagePicker url={form.imageUrl} uploading={imageUploading} onUpload={onUpload} /><label className="field-label md:col-span-2">رزومه فارسی<textarea className="admin-textarea" value={form.bioFa} onChange={e => field("bioFa", e.target.value)} /></label><label className="field-label md:col-span-2">English bio<textarea className="admin-textarea" dir="ltr" value={form.bioEn} onChange={e => field("bioEn", e.target.value)} /></label><label className="field-label">کلاس‌ها فارسی<textarea className="admin-textarea min-h-24" value={form.classesFa} onChange={e => field("classesFa", e.target.value)} placeholder="قدرت، کراس‌فیت&#10;هر مورد در یک خط" /></label><label className="field-label">Classes English<textarea className="admin-textarea min-h-24" dir="ltr" value={form.classesEn} onChange={e => field("classesEn", e.target.value)} /></label><label className="field-label">دیاگرام / مسیر پیشرفت فارسی<textarea className="admin-textarea min-h-32" value={form.diagramFa} onChange={e => field("diagramFa", e.target.value)} placeholder="مراحل یا نکات کلیدی پروفایل مربی" /></label><label className="field-label">Coach diagram English<textarea className="admin-textarea min-h-32" dir="ltr" value={form.diagramEn} onChange={e => field("diagramEn", e.target.value)} /></label></div>; }

function BranchForm({ form, field, imageUploading, onUpload }: { form: BranchForm; field: (key: keyof BranchForm, value: string | number) => void; imageUploading: boolean; onUpload: (file: File | undefined) => void }) { return <div className="grid gap-4 md:grid-cols-2"><label className="field-label">نام فارسی شعبه<Input value={form.nameFa} onChange={e => field("nameFa", e.target.value)} /></label><label className="field-label">English name<Input dir="ltr" value={form.nameEn} onChange={e => field("nameEn", e.target.value)} /></label><label className="field-label">آدرس فارسی<textarea className="admin-textarea" value={form.addressFa} onChange={e => field("addressFa", e.target.value)} /></label><label className="field-label">English address<textarea className="admin-textarea" dir="ltr" value={form.addressEn} onChange={e => field("addressEn", e.target.value)} /></label><label className="field-label">شماره تماس<Input dir="ltr" value={form.phone} onChange={e => field("phone", e.target.value)} /></label><label className="field-label">لینک Google Maps<Input dir="ltr" value={form.mapsUrl} onChange={e => field("mapsUrl", e.target.value)} placeholder="https://maps.google.com/..." /></label><label className="field-label">برچسب فارسی<Input value={form.tagFa} onChange={e => field("tagFa", e.target.value)} /></label><label className="field-label">English tag<Input dir="ltr" value={form.tagEn} onChange={e => field("tagEn", e.target.value)} /></label><ImagePicker url={form.imageUrl} uploading={imageUploading} onUpload={onUpload} /><label className="field-label">توضیح فارسی<textarea className="admin-textarea" value={form.descriptionFa} onChange={e => field("descriptionFa", e.target.value)} /></label><label className="field-label">English description<textarea className="admin-textarea" dir="ltr" value={form.descriptionEn} onChange={e => field("descriptionEn", e.target.value)} /></label></div>; }
