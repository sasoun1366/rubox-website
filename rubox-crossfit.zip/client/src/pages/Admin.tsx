import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowDown, ArrowUp, ArrowUpRight, Check, ImagePlus, Loader2, Plus, Trash2, UploadCloud, X } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import AdminEntities from "@/components/AdminEntities";
import AdminUsers from "@/components/AdminUsers";
import AdminActivity from "@/components/AdminActivity";
import AdminAnalytics from "@/components/AdminAnalytics";
import AdminSeoAssistant from "@/components/AdminSeoAssistant";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function uploadImage(file: File) {
  const data = await fileToDataUrl(file);
  const response = await fetch("/api/admin/upload", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fileName: file.name, contentType: file.type, data }) });
  if (!response.ok) throw new Error("آپلود تصویر انجام نشد");
  return response.json() as Promise<{ url: string; key: string }>;
}

const timetableEntities = [
  { type: "branch" as const, id: 1, fa: "شعبه فرشته", en: "Fereshteh" },
  { type: "branch" as const, id: 2, fa: "شعبه نیاوران", en: "Niavaran" },
  { type: "branch" as const, id: 3, fa: "شعبه سعادت‌آباد", en: "Saadat Abad" },
  { type: "coach" as const, id: 1, fa: "حمید یل", en: "Hamid Yal" },
  { type: "coach" as const, id: 2, fa: "پوریا محمدی", en: "Pouria Mohammadi" },
  { type: "coach" as const, id: 3, fa: "پرهام پاکزاد", en: "Parham Pakzad" },
  { type: "coach" as const, id: 4, fa: "پرهام پاکزارد", en: "Parham Pakzard" },
  { type: "coach" as const, id: 5, fa: "شهاب شمیرانی", en: "Shahab Shamirani" },
  { type: "coach" as const, id: 6, fa: "علی صیفی", en: "Ali Saeifi" },
  { type: "coach" as const, id: 7, fa: "الیار امیرفطهی", en: "Elyar Amirfatahi" },
  { type: "coach" as const, id: 8, fa: "سپهر غفاری", en: "Sepehr Ghaffari" },
  { type: "coach" as const, id: 9, fa: "نیلوفر ثابت", en: "Niloofar Sabet" },
  { type: "coach" as const, id: 10, fa: "مرضیه نمایی", en: "Marzieh Namayi" },
  { type: "coach" as const, id: 11, fa: "بهاره خادمی", en: "Bahareh Khademi" },
];
const timetableDays = [["شنبه", "Saturday"], ["یکشنبه", "Sunday"], ["دوشنبه", "Monday"], ["سه‌شنبه", "Tuesday"], ["چهارشنبه", "Wednesday"], ["پنج‌شنبه", "Thursday"]] as const;
type DraftEntry = { dayFa: string; dayEn: string; time: string; titleFa: string; titleEn: string; sortOrder: number };
const blankEntry = (index: number): DraftEntry => ({ dayFa: "شنبه", dayEn: "Saturday", time: "۰۷:۰۰", titleFa: "کلاس جدید", titleEn: "New class", sortOrder: index });
const defaultEntriesFor = (entity: (typeof timetableEntities)[number]): DraftEntry[] => {
  const branchDefaults: Record<number, DraftEntry[]> = {
    1: [["شنبه", "Saturday", "۰۷:۰۰", "کراس‌فیت مقدماتی", "CrossFit Basics"], ["دوشنبه", "Monday", "۰۹:۰۰", "آزمایش قدرت", "Strength Lab"], ["چهارشنبه", "Wednesday", "۱۸:۰۰", "WOD تیمی", "WOD Team"], ["پنج‌شنبه", "Thursday", "۲۰:۰۰", "موبیلیتی", "Mobility"]].map((row, sortOrder) => ({ dayFa: row[0], dayEn: row[1], time: row[2], titleFa: row[3], titleEn: row[4], sortOrder })),
    2: [["شنبه", "Saturday", "۰۷:۰۰", "ساخت موتور", "Engine Builder"], ["یکشنبه", "Sunday", "۰۹:۰۰", "لیفت المپیک", "Olympic Lifting"], ["سه‌شنبه", "Tuesday", "۱۸:۰۰", "کراس‌فیت سطح ۲", "CrossFit Level 2"], ["پنج‌شنبه", "Thursday", "۲۰:۰۰", "کاندیشنینگ", "Conditioning"]].map((row, sortOrder) => ({ dayFa: row[0], dayEn: row[1], time: row[2], titleFa: row[3], titleEn: row[4], sortOrder })),
    3: [["شنبه", "Saturday", "۰۸:۰۰", "تمرین گروهی", "Community WOD"], ["دوشنبه", "Monday", "۱۰:۰۰", "تمرین آزاد", "Open Gym"], ["چهارشنبه", "Wednesday", "۱۸:۰۰", "تمرین دونفره", "Partner Workout"], ["پنج‌شنبه", "Thursday", "۲۰:۰۰", "ریکاوری", "Recovery"]].map((row, sortOrder) => ({ dayFa: row[0], dayEn: row[1], time: row[2], titleFa: row[3], titleEn: row[4], sortOrder })),
  };
  if (entity.type === "branch") return branchDefaults[entity.id] ?? [blankEntry(0)];
  return [{ dayFa: "شنبه", dayEn: "Saturday", time: "۰۹:۰۰", titleFa: "کلاس اختصاصی", titleEn: "Personal class", sortOrder: 0 }, { dayFa: "دوشنبه", dayEn: "Monday", time: "۱۸:۰۰", titleFa: "کلاس گروهی", titleEn: "Group class", sortOrder: 1 }];
};

export default function Admin() {
  const { user } = useAuth();
  const panelAuth = trpc.panelAuth.me.useQuery();
  const can = (permission: string) => !panelAuth.data || panelAuth.data.permissions.includes(permission as (typeof panelAuth.data.permissions)[number]);
  const contentQuery = trpc.site.managedContent.useQuery(undefined, { enabled: can("content") });
  const galleryQuery = trpc.site.managedGallery.useQuery(undefined, { enabled: can("media") });
  const timetableQuery = trpc.site.managedTimetable.useQuery(undefined, { enabled: can("timetable") });
  const blogQuery = trpc.site.blog.managementList.useQuery(undefined, { enabled: can("blog") });
  const utils = trpc.useUtils();
  const updateContent = trpc.site.updateContent.useMutation({ onSuccess: () => utils.site.managedContent.invalidate() });
  const addImage = trpc.site.addGalleryImage.useMutation({ onSuccess: () => utils.site.managedGallery.invalidate() });
  const removeImage = trpc.site.removeGalleryImage.useMutation({ onSuccess: () => utils.site.managedGallery.invalidate() });
  const updateTimetable = trpc.site.updateTimetable.useMutation({ onSuccess: () => { utils.site.managedTimetable.invalidate(); setNotice("تایم‌تیبل با موفقیت ذخیره شد."); } });
  const createArticle = trpc.site.blog.create.useMutation({ onSuccess: () => { utils.site.blog.managementList.invalidate(); setNotice("مقاله با موفقیت منتشر شد."); resetArticle(); } });
  const updateArticle = trpc.site.blog.update.useMutation({ onSuccess: () => { utils.site.blog.managementList.invalidate(); setNotice("مقاله به‌روزرسانی شد."); resetArticle(); } });
  const removeArticle = trpc.site.blog.remove.useMutation({ onSuccess: () => { utils.site.blog.managementList.invalidate(); setNotice("مقاله حذف شد."); } });
  const [form, setForm] = useState({ heroTitleFa: "", heroTitleEn: "", heroTextFa: "", heroTextEn: "", heroImageUrl: "", heroImageKey: "", ctaLabelFa: "", ctaLabelEn: "" });
  const [heroFile, setHeroFile] = useState<File | null>(null);
  const [galleryFile, setGalleryFile] = useState<File | null>(null);
  const [articleCoverFile, setArticleCoverFile] = useState<File | null>(null);
  const [articleCoverUploading, setArticleCoverUploading] = useState(false);
  const [galleryTitleFa, setGalleryTitleFa] = useState("");
  const [galleryTitleEn, setGalleryTitleEn] = useState("");
  const [notice, setNotice] = useState("");
  const [selectedEntityKey, setSelectedEntityKey] = useState("branch:1");
  const [draftEntries, setDraftEntries] = useState<DraftEntry[]>(defaultEntriesFor(timetableEntities[0]));
  const emptyArticle = { slug: "", titleFa: "", titleEn: "", excerptFa: "", excerptEn: "", metaTitleFa: "", metaDescriptionFa: "", keywordsFa: "", keywordsEn: "", bodyFa: "", bodyEn: "", category: "آموزش کراس‌فیت", readTime: 5, coverImageUrl: "", published: 1 };
  const [articleDraft, setArticleDraft] = useState(emptyArticle);
  const [editingArticleId, setEditingArticleId] = useState<number | null>(null);

  function resetArticle() {
    setArticleDraft(emptyArticle);
    setEditingArticleId(null);
    setArticleCoverFile(null);
  }

  const setArticleField = (key: keyof typeof emptyArticle, value: string | number) => setArticleDraft(current => ({ ...current, [key]: value }));
  const uploadArticleCover = async (file: File | null) => {
    if (!file) return;
    setArticleCoverFile(file);
    setArticleCoverUploading(true);
    try {
      const result = await uploadImage(file);
      setArticleField("coverImageUrl", result.url);
      setNotice("کاور مقاله آپلود شد؛ برای ثبت نهایی، مقاله را ذخیره کن.");
    } catch (error) {
      setArticleCoverFile(null);
      setNotice(error instanceof Error ? error.message : "آپلود کاور مقاله ناموفق بود.");
    } finally {
      setArticleCoverUploading(false);
    }
  };
  const editArticle = (article: NonNullable<typeof blogQuery.data>[number]) => {
    setEditingArticleId(article.id);
    setArticleCoverFile(null);
    setArticleDraft({ slug: article.slug, titleFa: article.titleFa, titleEn: article.titleEn, excerptFa: article.excerptFa, excerptEn: article.excerptEn, metaTitleFa: article.metaTitleFa ?? "", metaDescriptionFa: article.metaDescriptionFa ?? "", keywordsFa: article.keywordsFa ?? "", keywordsEn: article.keywordsEn ?? "", bodyFa: article.bodyFa, bodyEn: article.bodyEn, category: article.category, readTime: article.readTime, coverImageUrl: article.coverImageUrl ?? "", published: article.published });
  };
  const saveArticle = async () => {
    const payload = { ...articleDraft, coverImageUrl: articleDraft.coverImageUrl || null };
    try {
      if (editingArticleId) await updateArticle.mutateAsync({ id: editingArticleId, data: payload });
      else await createArticle.mutateAsync(payload);
    } catch (error) { setNotice(error instanceof Error ? error.message : "ذخیره مقاله ناموفق بود."); }
  };

  const selectedEntity = timetableEntities.find(entity => `${entity.type}:${entity.id}` === selectedEntityKey) ?? timetableEntities[0];
  useEffect(() => {
    const saved = (timetableQuery.data ?? []).filter(entry => entry.entityType === selectedEntity.type && entry.entityId === selectedEntity.id);
    setDraftEntries(saved.length ? saved.map(({ dayFa, dayEn, time, titleFa, titleEn, sortOrder }) => ({ dayFa, dayEn, time, titleFa, titleEn, sortOrder })) : defaultEntriesFor(selectedEntity));
  }, [timetableQuery.data, selectedEntity.type, selectedEntity.id]);

  useEffect(() => {
    if (contentQuery.data) setForm({ ...contentQuery.data, heroImageKey: contentQuery.data.heroImageKey ?? "" });
  }, [contentQuery.data]);

  const setField = (key: keyof typeof form, value: string) => setForm(current => ({ ...current, [key]: value }));
  const saveContent = async () => {
    try {
      let nextForm = form;
      if (heroFile) {
        const uploaded = await uploadImage(heroFile);
        nextForm = { ...form, heroImageUrl: uploaded.url, heroImageKey: uploaded.key };
        setForm(nextForm);
        setHeroFile(null);
      }
      await updateContent.mutateAsync(nextForm);
      setNotice("محتوا با موفقیت ذخیره شد.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "ذخیره‌سازی ناموفق بود."); }
  };
  const addGallery = async () => {
    if (!galleryFile || !galleryTitleFa || !galleryTitleEn) return setNotice("عنوان فارسی، انگلیسی و تصویر را وارد کنید.");
    try {
      const uploaded = await uploadImage(galleryFile);
      await addImage.mutateAsync({ titleFa: galleryTitleFa, titleEn: galleryTitleEn, url: uploaded.url, fileKey: uploaded.key });
      setGalleryFile(null); setGalleryTitleFa(""); setGalleryTitleEn(""); setNotice("تصویر به گالری اضافه شد.");
    } catch (error) { setNotice(error instanceof Error ? error.message : "افزودن تصویر ناموفق بود."); }
  };
  const changeEntry = (index: number, key: keyof DraftEntry, value: string) => setDraftEntries(current => current.map((entry, entryIndex) => entryIndex === index ? { ...entry, [key]: key === "sortOrder" ? Number(value) : value, ...(key === "dayFa" ? { dayEn: timetableDays.find(day => day[0] === value)?.[1] ?? entry.dayEn } : {}) } : entry));
  const saveTimetable = async () => {
    try { await updateTimetable.mutateAsync({ entityType: selectedEntity.type, entityId: selectedEntity.id, entries: draftEntries.map((entry, index) => ({ ...entry, sortOrder: index })) }); }
    catch (error) { setNotice(error instanceof Error ? error.message : "ذخیره تایم‌تیبل ناموفق بود."); }
  };
  const addEntry = () => setDraftEntries(current => [...current, blankEntry(current.length)]);
  const removeEntry = (index: number) => setDraftEntries(current => current.filter((_, entryIndex) => entryIndex !== index).map((entry, entryIndex) => ({ ...entry, sortOrder: entryIndex })));
  const moveEntry = (index: number, direction: -1 | 1) => setDraftEntries(current => { const next = index + direction; if (next < 0 || next >= current.length) return current; const copy = [...current]; [copy[index], copy[next]] = [copy[next], copy[index]]; return copy.map((entry, entryIndex) => ({ ...entry, sortOrder: entryIndex })); });

  const applySeoSuggestion = (suggestion: { slugSuggestion: string; metaTitleFa: string; metaDescriptionFa: string; keywordsFa: string[]; keywordsEn: string[] }) => { setArticleDraft(current => ({ ...current, slug: suggestion.slugSuggestion, metaTitleFa: suggestion.metaTitleFa, metaDescriptionFa: suggestion.metaDescriptionFa, keywordsFa: suggestion.keywordsFa.join(", "), keywordsEn: suggestion.keywordsEn.join(", ") })); setNotice("پیشنهادهای SEO در فرم مقاله اعمال شد؛ برای ذخیره نهایی مقاله را ثبت کن."); };
  return <DashboardLayout><div dir="rtl" className="min-h-screen bg-[#f7f5f1] text-[#171717] -m-4 p-5 md:p-8 lg:p-10">
    <div className="mx-auto max-w-6xl"><div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-xs font-bold tracking-[.22em] text-[#111111]">RUBOX / CONTROL ROOM</p><h1 className="mt-2 text-3xl font-black tracking-tight">پنل مدیریت روباکس</h1><p className="mt-2 text-sm text-black/55">محتوا، رسانه و برنامه کلاس‌ها را از یک فضای واحد مدیریت کن.</p></div><Link href="/" className="flex items-center gap-2 text-sm font-bold text-black/60 transition hover:text-[#111111]">مشاهده سایت عمومی <ArrowUpRight size={16} /></Link></div>
      {!user && !panelAuth.data ? <div className="rounded-3xl bg-white p-8 shadow-sm">برای دسترسی به پنل باید وارد حساب مدیر شوید.</div> : user && user.role !== "admin" && !panelAuth.data ? <div className="rounded-3xl bg-white p-8 shadow-sm">این حساب دسترسی مدیر ندارد. از حساب مالک پروژه استفاده کنید.</div> : <>
      <AdminAnalytics />
      {notice && <div className="mb-6 flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"><Check size={16} />{notice}</div>}<div id="overview" className="admin-overview-grid mb-7"><div className="admin-stat-card"><span className="admin-stat-icon">◷</span><div><span className="admin-stat-label">مقالات منتشرشده</span><strong>{blogQuery.data?.filter(article => article.published).length ?? 0}</strong></div><span className="admin-stat-trend">+12%</span></div><div className="admin-stat-card"><span className="admin-stat-icon">▦</span><div><span className="admin-stat-label">تصاویر گالری</span><strong>{galleryQuery.data?.length ?? 0}</strong></div><span className="admin-stat-trend">فعال</span></div><div className="admin-stat-card"><span className="admin-stat-icon">↗</span><div><span className="admin-stat-label">کلاس‌های برنامه‌ریزی‌شده</span><strong>{timetableQuery.data?.length ?? 0}</strong></div><span className="admin-stat-trend">این هفته</span></div><div className="admin-stat-card admin-stat-card-dark"><div><span className="admin-stat-label">وضعیت سایت</span><strong>آنلاین</strong></div><div className="admin-live-dot" /></div></div>{(can("coaches") || can("branches")) && <AdminEntities />}{user?.role === "admin" && <><AdminUsers /><AdminActivity /></>}{can("content") && <section id="hero" className="grid gap-6 lg:grid-cols-[1.25fr_.75fr]"><div className="rounded-3xl bg-white p-6 shadow-sm md:p-8"><div className="mb-7 flex items-center justify-between"><div><p className="text-xs font-bold tracking-[.18em] text-black/35">HERO CONTENT</p><h2 className="mt-2 text-2xl font-black">محتوای هدر</h2></div><ImagePlus className="text-[#111111]" /></div><div className="grid gap-5 md:grid-cols-2"><label className="field-label">عنوان فارسی<textarea className="admin-textarea" value={form.heroTitleFa} onChange={e => setField("heroTitleFa", e.target.value)} /></label><label className="field-label">English headline<textarea className="admin-textarea" dir="ltr" value={form.heroTitleEn} onChange={e => setField("heroTitleEn", e.target.value)} /></label><label className="field-label md:col-span-2">توضیح فارسی<textarea className="admin-textarea min-h-24" value={form.heroTextFa} onChange={e => setField("heroTextFa", e.target.value)} /></label><label className="field-label md:col-span-2">English description<textarea className="admin-textarea min-h-24" dir="ltr" value={form.heroTextEn} onChange={e => setField("heroTextEn", e.target.value)} /></label><label className="field-label">متن دکمه فارسی<Input value={form.ctaLabelFa} onChange={e => setField("ctaLabelFa", e.target.value)} /></label><label className="field-label">English CTA<Input dir="ltr" value={form.ctaLabelEn} onChange={e => setField("ctaLabelEn", e.target.value)} /></label></div><div className="mt-6 rounded-2xl border border-dashed border-black/15 p-4"><p className="mb-3 text-sm font-bold">تصویر هدر</p><div className="flex flex-col gap-3 sm:flex-row sm:items-center"><label className="flex cursor-pointer items-center gap-2 rounded-xl bg-black px-4 py-3 text-sm font-bold text-white transition hover:bg-[#111111]"><UploadCloud size={17} />{heroFile ? heroFile.name : "انتخاب تصویر جدید"}<input type="file" accept="image/*" className="hidden" onChange={e => setHeroFile(e.target.files?.[0] ?? null)} /></label><span className="text-xs text-black/45">JPG/PNG تا ۱۵ مگابایت</span></div></div><Button onClick={saveContent} disabled={updateContent.isPending} className="mt-7 h-12 rounded-xl bg-[#111111] px-6 font-bold hover:bg-[#333333]">{updateContent.isPending ? <Loader2 className="animate-spin" /> : "ذخیره تغییرات"}</Button></div><div className="rounded-3xl bg-[#151515] p-6 text-white shadow-sm md:p-8"><p className="text-xs font-bold tracking-[.18em] text-white/40">LIVE PREVIEW</p><div className="mt-6 overflow-hidden rounded-2xl bg-black">{form.heroImageUrl ? <img src={form.heroImageUrl} alt="Hero preview" className="aspect-[4/3] w-full object-cover" /> : <div className="flex aspect-[4/3] items-center justify-center bg-[#242424] text-sm text-white/45">تصویر هدر هنوز بارگذاری نشده است</div>}<div className="p-5"><p className="whitespace-pre-line text-2xl font-black leading-none">{form.heroTitleFa || "عنوان فارسی"}</p><p className="mt-3 text-sm text-white/55">{form.heroTextFa || "توضیح کوتاه صفحه اصلی"}</p></div></div><p className="mt-5 text-sm leading-6 text-white/45">تصویر جدید بعد از ذخیره روی هدر صفحه اصلی نمایش داده می‌شود.</p></div></section>}
      <section id="media" className="mt-6 rounded-3xl bg-white p-6 shadow-sm md:p-8">{can("timetable") && <><div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-xs font-bold tracking-[.18em] text-black/35">TIMETABLE CONTROL</p><h2 className="mt-2 text-2xl font-black">مدیریت تایم‌تیبل شعب و مربیان</h2><p className="mt-2 text-sm text-black/50">روز، ساعت و نام کلاس‌ها را تغییر بده؛ تغییرات بعد از ذخیره در سایت عمومی نمایش داده می‌شوند.</p></div><Button onClick={addEntry} variant="outline" className="h-11 rounded-xl border-black/15 font-bold"><Plus size={17} />ردیف جدید</Button></div><div className="mb-6 flex flex-wrap gap-2">{timetableEntities.map(entity => <button key={`${entity.type}:${entity.id}`} onClick={() => setSelectedEntityKey(`${entity.type}:${entity.id}`)} className={`rounded-full border px-4 py-2 text-xs font-bold transition ${selectedEntityKey === `${entity.type}:${entity.id}` ? "border-black bg-black text-white" : "border-black/10 bg-[#f7f5f1] text-black/60 hover:border-black/30"}`}>{entity.fa}<span className="ms-2 text-[10px] opacity-50">{entity.type === "branch" ? "شعبه" : "مربی"}</span></button>)}</div><div className="space-y-3">{draftEntries.map((entry, index) => <div key={`${selectedEntityKey}-${index}`} className="grid gap-3 rounded-2xl border border-black/10 bg-[#f7f5f1] p-4 md:grid-cols-[.75fr_.75fr_1fr_1fr_auto] md:items-end"><label className="field-label">روز<select className="admin-select" value={entry.dayFa} onChange={e => changeEntry(index, "dayFa", e.target.value)}>{timetableDays.map(day => <option key={day[0]} value={day[0]}>{day[0]}</option>)}</select></label><label className="field-label">ساعت<Input dir="ltr" value={entry.time} onChange={e => changeEntry(index, "time", e.target.value)} placeholder="۰۷:۰۰" /></label><label className="field-label">نام فارسی<Input value={entry.titleFa} onChange={e => changeEntry(index, "titleFa", e.target.value)} /></label><label className="field-label">English class<Input dir="ltr" value={entry.titleEn} onChange={e => changeEntry(index, "titleEn", e.target.value)} /></label><div className="flex items-center gap-1"><button type="button" onClick={() => moveEntry(index, -1)} className="rounded-lg p-2 text-black/45 transition hover:bg-white hover:text-black" aria-label="جابجایی به بالا"><ArrowUp size={15} /></button><button type="button" onClick={() => moveEntry(index, 1)} className="rounded-lg p-2 text-black/45 transition hover:bg-white hover:text-black" aria-label="جابجایی به پایین"><ArrowDown size={15} /></button><button type="button" onClick={() => removeEntry(index)} className="rounded-lg p-2 text-black/45 transition hover:bg-white hover:text-red-600" aria-label="حذف ردیف"><X size={15} /></button></div></div>)}</div><div className="mt-6 flex flex-col justify-between gap-4 border-t border-black/10 pt-6 sm:flex-row sm:items-center"><p className="text-sm text-black/45">در حال ویرایش: <strong className="text-black">{selectedEntity.fa}</strong> · {draftEntries.length} ردیف</p><Button onClick={saveTimetable} disabled={updateTimetable.isPending} className="h-12 rounded-xl bg-black px-7 font-bold hover:bg-[#222]">{updateTimetable.isPending ? <Loader2 className="animate-spin" /> : "ذخیره تایم‌تیبل"}</Button></div>      </>}{can("blog") && <><section id="timetable" className="mt-6 rounded-3xl bg-white p-6 shadow-sm md:p-8"><div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-xs font-bold tracking-[.18em] text-black/35">BLOG / JOURNAL</p><h2 className="mt-2 text-2xl font-black">مدیریت مقالات آموزشی</h2><p className="mt-2 text-sm text-black/50">مقاله‌ها را به دو زبان ایجاد، ویرایش، منتشر یا از سایت پنهان کن.</p></div><Button type="button" variant="outline" onClick={resetArticle} className="h-11 rounded-xl border-black/15 font-bold">مقاله جدید <Plus size={17} /></Button></div><div className="grid gap-5 lg:grid-cols-2"><label className="field-label">Slug انگلیسی<Input dir="ltr" value={articleDraft.slug} onChange={e => setArticleField("slug", e.target.value)} placeholder="crossfit-for-beginners" /></label><label className="field-label">دسته‌بندی<Input value={articleDraft.category} onChange={e => setArticleField("category", e.target.value)} /></label><label className="field-label">عنوان فارسی<textarea className="admin-textarea" value={articleDraft.titleFa} onChange={e => setArticleField("titleFa", e.target.value)} /></label><label className="field-label">English title<textarea className="admin-textarea" dir="ltr" value={articleDraft.titleEn} onChange={e => setArticleField("titleEn", e.target.value)} /></label><label className="field-label">خلاصه فارسی<textarea className="admin-textarea min-h-24" value={articleDraft.excerptFa} onChange={e => setArticleField("excerptFa", e.target.value)} /></label><label className="field-label">English excerpt<textarea className="admin-textarea min-h-24" dir="ltr" value={articleDraft.excerptEn} onChange={e => setArticleField("excerptEn", e.target.value)} /></label><label className="field-label md:col-span-2">متن کامل فارسی<textarea className="admin-textarea min-h-36" value={articleDraft.bodyFa} onChange={e => setArticleField("bodyFa", e.target.value)} /></label><label className="field-label md:col-span-2">Full English body<textarea className="admin-textarea min-h-36" dir="ltr" value={articleDraft.bodyEn} onChange={e => setArticleField("bodyEn", e.target.value)} /></label><div className="field-label"><span>تصویر کاور مقاله</span><label className="mt-2 flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-black/20 bg-[#f7f5f1] px-4 py-3 text-sm font-bold transition hover:border-black/50"><UploadCloud size={17} />{articleCoverUploading ? "در حال آپلود..." : articleCoverFile?.name || (articleDraft.coverImageUrl ? "کاور فعلی ثبت شده؛ انتخاب تصویر جدید" : "انتخاب تصویر از دستگاه")}<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" disabled={articleCoverUploading} onChange={e => uploadArticleCover(e.target.files?.[0] ?? null)} /></label>{articleDraft.coverImageUrl && <img src={articleDraft.coverImageUrl} alt="پیش‌نمایش کاور مقاله" className="mt-3 h-28 w-full rounded-xl object-cover" />}</div><label className="field-label">زمان مطالعه، دقیقه<Input type="number" min="1" max="120" value={articleDraft.readTime} onChange={e => setArticleField("readTime", Number(e.target.value))} /></label></div><div className="mt-5 flex flex-col justify-between gap-4 border-t border-black/10 pt-5 sm:flex-row sm:items-center"><label className="flex items-center gap-3 text-sm font-bold"><input type="checkbox" checked={articleDraft.published === 1} onChange={e => setArticleField("published", e.target.checked ? 1 : 0)} /> انتشار در سایت عمومی</label><Button type="button" onClick={saveArticle} disabled={createArticle.isPending || updateArticle.isPending} className="h-12 rounded-xl bg-black px-7 font-bold hover:bg-[#222]">{createArticle.isPending || updateArticle.isPending ? <Loader2 className="animate-spin" /> : editingArticleId ? "ذخیره ویرایش" : "انتشار مقاله"}</Button></div></section><AdminSeoAssistant draft={articleDraft} onApply={applySeoSuggestion} /><section id="blog-editor" className="mt-6 rounded-3xl bg-white p-6 shadow-sm md:p-8"><div className="mb-6 flex items-center justify-between"><div><p className="text-xs font-bold tracking-[.18em] text-black/35">PUBLISHED ARTICLES</p><h2 className="mt-2 text-2xl font-black">فهرست مقالات</h2></div><span className="rounded-full bg-[#f7f5f1] px-3 py-1 text-xs font-bold text-black/55">{blogQuery.data?.length ?? 0} مقاله</span></div><div className="grid gap-3">{(blogQuery.data ?? []).map(article => <div key={article.id} className="flex flex-col justify-between gap-4 rounded-2xl border border-black/10 bg-[#f7f5f1] p-4 sm:flex-row sm:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-black">{article.titleFa}</h3><span className={`rounded-full px-2 py-1 text-[10px] font-bold ${article.published ? "bg-emerald-100 text-emerald-700" : "bg-black/10 text-black/45"}`}>{article.published ? "منتشرشده" : "پیش‌نویس"}</span></div><p className="mt-1 text-xs text-black/45">/{article.slug} · {article.category}</p></div><div className="flex items-center gap-2"><Button type="button" variant="outline" onClick={() => editArticle(article)} className="h-9 rounded-lg border-black/15 px-3 text-xs font-bold">ویرایش</Button><button type="button" onClick={() => { if (window.confirm("این مقاله حذف شود؟")) removeArticle.mutate({ id: article.id }); }} className="rounded-lg p-2 text-black/45 transition hover:bg-white hover:text-red-600" aria-label="حذف مقاله"><Trash2 size={16} /></button></div></div>)}</div></section>
</>}
</section>
</>}
    </div></div></DashboardLayout>;
}
