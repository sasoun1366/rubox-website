import { ArrowRight, Clock, Instagram, Send } from "lucide-react";
import { useEffect } from "react";
import { Link, useParams } from "wouter";
import { trpc } from "@/lib/trpc";

const SITE_URL = "https://ruboxfit-n8vu83tm.manus.space";

export default function BlogArticle() {
  const { slug } = useParams<{ slug: string }>();
  const articlesQuery = trpc.site.blog.list.useQuery({ publishedOnly: true });
  const article = articlesQuery.data?.find(item => item.slug === slug);

  useEffect(() => {
    void fetch("/api/analytics/pageview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ path: window.location.pathname, referrer: document.referrer }) }).catch(() => undefined);
    if (!article) return;
    const title = article.metaTitleFa || article.titleFa;
    const description = article.metaDescriptionFa || article.excerptFa;
    const canonical = `${SITE_URL}/blog/${article.slug}`;
    document.documentElement.lang = "fa";
    document.documentElement.dir = "rtl";
    document.title = `${title} | مجله روباکس`;
    const setMeta = (selector: string, attribute: string, value: string) => {
      let node = document.head.querySelector<HTMLMetaElement>(selector);
      if (!node) { node = document.createElement("meta"); node.setAttribute(attribute, selector.split('"')[1]); document.head.appendChild(node); }
      node.setAttribute("content", value);
    };
    setMeta('meta[name="description"]', "name", description);
    setMeta('meta[property="og:title"]', "property", title);
    setMeta('meta[property="og:description"]', "property", description);
    setMeta('meta[property="og:url"]', "property", canonical);
    setMeta('meta[property="og:type"]', "property", "article");
    if (article.keywordsFa) setMeta('meta[name="keywords"]', "name", article.keywordsFa);
    if (article.coverImageUrl) setMeta('meta[property="og:image"]', "property", `${SITE_URL}${article.coverImageUrl}`);
    let link = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!link) { link = document.createElement("link"); link.rel = "canonical"; document.head.appendChild(link); }
    link.href = canonical;
    return () => { document.title = "ROWBOX | باشگاه کراس‌فیت در تهران"; };
  }, [article]);

  if (articlesQuery.isLoading) {
    return <main className="min-h-screen bg-[#0b0b0b] p-8 text-white">در حال بارگذاری مقاله...</main>;
  }

  if (!article) {
    return (
      <main dir="rtl" className="flex min-h-screen flex-col items-center justify-center gap-6 bg-[#0b0b0b] p-8 text-center text-white">
        <h1 className="text-4xl font-black">مقاله پیدا نشد</h1>
        <Link href="/#blog" className="rounded-full bg-white px-5 py-3 text-sm font-bold text-black">بازگشت به مجله</Link>
      </main>
    );
  }

  const title = article.metaTitleFa || article.titleFa;
  const description = article.metaDescriptionFa || article.excerptFa;
  const canonical = `${SITE_URL}/blog/${article.slug}`;
  const schema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: title,
    description,
    datePublished: new Date(article.publishedAt).toISOString(),
    dateModified: new Date(article.updatedAt).toISOString(),
    mainEntityOfPage: canonical,
    author: { "@type": "Organization", name: "ROWBOX" },
    publisher: { "@type": "Organization", name: "ROWBOX", logo: { "@type": "ImageObject", url: `${SITE_URL}/manus-storage/IMG_9225_16da6c84.webp` } },
    image: article.coverImageUrl ? `${SITE_URL}${article.coverImageUrl}` : undefined,
  };

  return (
    <main dir="rtl" className="min-h-screen bg-[#0b0b0b] text-[#f5f2ed]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-7 lg:px-10">
        <Link href="/" className="text-lg font-black tracking-[.22em]">ROWBOX</Link>
        <Link href="/#blog" className="inline-flex items-center gap-2 text-sm text-white/65 transition hover:text-white"><ArrowRight size={16} />مجله روباکس</Link>
      </header>
      <article className="mx-auto max-w-4xl px-6 pb-20 pt-12 lg:px-10 lg:pt-20">
        {article.coverImageUrl && (
          <img src={article.coverImageUrl} alt={title} className="mb-12 max-h-[520px] w-full object-cover grayscale" />
        )}
        <div className="max-w-3xl">
          <div className="flex items-center gap-4 text-xs font-bold tracking-[.15em] text-white/45"><span>{article.category}</span><span className="inline-flex items-center gap-1"><Clock size={13} />{article.readTime} دقیقه مطالعه</span></div>
          <h1 className="mt-6 text-5xl font-black leading-tight tracking-[-.06em] sm:text-7xl">{title}</h1>
          <p className="mt-8 text-xl leading-9 text-white/65">{description}</p>
          <div className="mt-12 border-t border-white/10 pt-10"><p className="whitespace-pre-line text-lg leading-10 text-white/80">{article.bodyFa}</p></div>
        </div>
      </article>
      <footer className="mx-auto flex max-w-5xl items-center justify-between border-t border-white/10 px-6 py-8 text-white/50 lg:px-10"><span className="text-xs">ROWBOX JOURNAL</span><div className="flex items-center gap-4"><a href="https://instagram.com/rowbox2023" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={18} /></a><a href="https://t.me/Rowbox2023" target="_blank" rel="noreferrer" aria-label="Telegram"><Send size={18} /></a></div></footer>
    </main>
  );
}
