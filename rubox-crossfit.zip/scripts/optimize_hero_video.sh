#!/usr/bin/env bash
set -euo pipefail

INPUT="${1:-/home/ubuntu/upload/PT_LANDING_PAGE_WEB_1440x900-optimized.mp4}"
OUTPUT="${2:-/home/ubuntu/webdev-static-assets/rowbox-hero-lite.webm}"

mkdir -p "$(dirname "$OUTPUT")"
ffmpeg -y -i "$INPUT" \
  -vf "scale='min(1280,iw)':-2,fps=30" \
  -an -c:v libvpx-vp9 -b:v 0 -crf 34 -row-mt 1 -deadline good -cpu-used 2 \
  "$OUTPUT"

echo "Optimized video: $OUTPUT"
ls -lh "$OUTPUT"
