import { describe, expect, it } from "vitest";
import { hashPanelPassword, verifyPanelPassword } from "./db";
import { appRouter } from "./routers";

describe("panel authentication", () => {
  it("hashes passwords and rejects invalid credentials", () => {
    const hash = hashPanelPassword("Rowbox-strong-pass-123");
    expect(hash).not.toContain("Rowbox-strong-pass-123");
    expect(verifyPanelPassword("Rowbox-strong-pass-123", hash)).toBe(true);
    expect(verifyPanelPassword("wrong-password", hash)).toBe(false);
  });

  it("requires the current password before clearing the first-login flag", async () => {
    const panelUser = { id: 7, username: "reception", passwordHash: hashPanelPassword("temporary-pass"), displayName: "پذیرش", permissions: '["timetable"]', active: 1, forcePasswordChange: 1, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: null };
    const ctx = { user: null, panelUser, req: { protocol: "https", headers: {} } as any, res: { clearCookie: () => undefined } as any };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.panelAuth.changePassword({ currentPassword: "bad-pass", newPassword: "new-secure-pass" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.panelAuth.changePassword({ currentPassword: "temporary-pass", newPassword: "new-secure-pass" })).resolves.toEqual({ success: true });
  });
});
