import { and, desc, eq } from "drizzle-orm";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { drizzle } from "drizzle-orm/mysql2";
import {
  blogArticles,
  BlogArticle,
  InsertBlogArticle,
  galleryImages,
  InsertGalleryImage,
  InsertSiteContent,
  InsertUser,
  coaches,
  branches,
  InsertCoach,
  InsertBranch,
  siteContent,
  timetableEntries,
  InsertTimetableEntry,
  users,
  panelUsers,
  panelSessions,
  panelActivityLogs,
  pageViewEvents,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

const FALLBACK_CONTENT = {
  id: 1,
  heroTitleFa: "قدرتت را\nاز نو بساز.",
  heroTitleEn: "BUILD YOUR\nINNER FORCE.",
  heroTextFa: "کراس‌فیت برای آدم‌هایی که معمولی بودن را انتخاب نمی‌کنند.",
  heroTextEn: "CrossFit for people who refuse to settle for ordinary.",
  heroImageUrl: "/manus-storage/rubox-hero_45e1bc62.jpg",
  heroImageKey: "rubox-hero_45e1bc62.jpg",
  ctaLabelFa: "یک جلسه مهمان رایگان",
  ctaLabelEn: "Claim a free trial",
  updatedAt: new Date(),
};

const FALLBACK_GALLERY = [
  {
    id: 1,
    titleFa: "قدرت در جمع ساخته می‌شود",
    titleEn: "Strength is built together",
    url: "/manus-storage/rubox-training_902f0284.jpg",
    fileKey: "rubox-training_902f0284.jpg",
    createdAt: new Date(),
  },
  {
    id: 2,
    titleFa: "تمرکز. کنترل. پیشرفت.",
    titleEn: "Focus. Control. Progress.",
    url: "/manus-storage/rubox-coach_bd3bac71.jpg",
    fileKey: "rubox-coach_bd3bac71.jpg",
    createdAt: new Date(),
  },
];

const FALLBACK_ARTICLES: BlogArticle[] = [
  {
    id: 1,
    slug: "crossfit-for-beginners",
    titleFa: "کراس‌فیت برای مبتدی‌ها؛ از کجا شروع کنیم؟",
    titleEn: "CrossFit for beginners: where to start",
    excerptFa: "راهنمای ساده برای شروع ایمن، ساختن عادت تمرینی و انتخاب کلاس مناسب در روباکس.",
    excerptEn: "A simple guide to starting safely, building consistency and choosing the right Rubox class.",
    metaTitleFa: "کراس‌فیت برای مبتدی‌ها | راهنمای شروع روباکس",
    metaDescriptionFa: "راهنمای شروع کراس‌فیت برای مبتدی‌ها در روباکس تهران؛ از انتخاب کلاس تا تمرین ایمن.",
    keywordsFa: "کراس‌فیت مبتدی, باشگاه کراس‌فیت تهران, شروع کراس‌فیت",
    keywordsEn: "crossfit beginners, crossfit gym Tehran, start crossfit",
    bodyFa: "شروع کراس‌فیت به رکورد زدن از روز اول وابسته نیست. با یک ارزیابی کوتاه، یادگیری فرم صحیح و سه جلسه منظم در هفته شروع کنید. مربی باید شدت تمرین را با سطح آمادگی شما هماهنگ کند و پیشرفت را با کیفیت حرکت بسنجد.",
    bodyEn: "Starting CrossFit is not about chasing a record on day one. Begin with a short assessment, sound movement mechanics and three consistent sessions per week. Your coach should scale intensity to your current fitness and measure progress through quality movement.",
    category: "راهنمای شروع",
    readTime: 5,
    coverImageUrl: "/manus-storage/rubox-training_e76504ea.webp",
    published: 1,
    publishedAt: new Date("2026-09-15"),
    createdAt: new Date("2026-09-15"),
    updatedAt: new Date("2026-09-15"),
  },
  {
    id: 2,
    slug: "recovery-after-training",
    titleFa: "ریکاوری بعد از تمرین؛ چهار عادت که نتیجه را بهتر می‌کند",
    titleEn: "Post-workout recovery: four habits that improve results",
    excerptFa: "از خواب و آب‌رسانی تا موبیلیتی؛ ریکاوری هوشمند بخش مهمی از برنامه تمرینی است.",
    excerptEn: "From sleep and hydration to mobility, smart recovery is a core part of your training plan.",
    metaTitleFa: "ریکاوری بعد از تمرین | چهار عادت مهم",
    metaDescriptionFa: "چهار عادت ساده برای ریکاوری بهتر بعد از تمرین کراس‌فیت؛ خواب، آب‌رسانی، تغذیه و موبیلیتی.",
    keywordsFa: "ریکاوری کراس‌فیت, ریکاوری بعد تمرین, موبیلیتی",
    keywordsEn: "crossfit recovery, post workout recovery, mobility",
    bodyFa: "خواب کافی، آب‌رسانی، دریافت پروتئین و چند دقیقه موبیلیتی سبک، چهار پایه ریکاوری هستند. اگر درد تیز یا خستگی غیرمعمول دارید، شدت تمرین را کم کنید و با مربی مشورت کنید.",
    bodyEn: "Adequate sleep, hydration, protein intake and a few minutes of light mobility are four recovery foundations. If you feel sharp pain or unusual fatigue, reduce intensity and speak with your coach.",
    category: "ریکاوری",
    readTime: 4,
    coverImageUrl: "/manus-storage/rubox-coach_cf9def3a.webp",
    published: 1,
    publishedAt: new Date("2026-09-15"),
    createdAt: new Date("2026-09-15"),
    updatedAt: new Date("2026-09-15"),
  },
];

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (!Object.keys(updateSet).length) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export const PANEL_PERMISSION_KEYS = ["overview", "content", "media", "coaches", "branches", "timetable", "blog", "users"] as const;
export type PanelPermission = (typeof PANEL_PERMISSION_KEYS)[number];
export function hashPanelPassword(password: string) { const salt = randomBytes(16).toString("hex"); return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`; }
export function verifyPanelPassword(password: string, stored: string) { const [salt, digest] = stored.split(":"); if (!salt || !digest) return false; const actual = scryptSync(password, salt, 64); const expected = Buffer.from(digest, "hex"); return actual.length === expected.length && timingSafeEqual(actual, expected); }
export function hashPanelToken(token: string) { return createHash("sha256").update(token).digest("hex"); }
export function parsePanelPermissions(value: string): PanelPermission[] { try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed.filter((permission): permission is PanelPermission => PANEL_PERMISSION_KEYS.includes(permission)) : []; } catch { return []; } }
export function serializePanelPermissions(permissions: string[]) { return JSON.stringify(permissions.filter(permission => (PANEL_PERMISSION_KEYS as readonly string[]).includes(permission))); }
export async function getPanelUserBySessionToken(token: string) { const db = await getDb(); if (!db) return undefined; const rows = await db.select({ user: panelUsers, expiresAt: panelSessions.expiresAt }).from(panelSessions).innerJoin(panelUsers, eq(panelSessions.panelUserId, panelUsers.id)).where(eq(panelSessions.tokenHash, hashPanelToken(token))).limit(1); const row = rows[0]; if (!row || !row.user.active || row.expiresAt < new Date()) return undefined; return row.user; }
export async function createPanelSession(panelUserId: number) { const db = await getDb(); const token = randomBytes(32).toString("hex"); if (!db) return token; await db.insert(panelSessions).values({ panelUserId, tokenHash: hashPanelToken(token), expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30) }); await db.update(panelUsers).set({ lastSignedIn: new Date() }).where(eq(panelUsers.id, panelUserId)); return token; }
export async function deletePanelSession(token: string) { const db = await getDb(); if (db) await db.delete(panelSessions).where(eq(panelSessions.tokenHash, hashPanelToken(token))); }
export async function getPanelUserByUsername(username: string) { const db = await getDb(); if (!db) return undefined; const rows = await db.select().from(panelUsers).where(eq(panelUsers.username, username)).limit(1); return rows[0]; }
export async function getPanelUsers() { const db = await getDb(); if (!db) return []; return db.select({ id: panelUsers.id, username: panelUsers.username, displayName: panelUsers.displayName, permissions: panelUsers.permissions, active: panelUsers.active, createdAt: panelUsers.createdAt, lastSignedIn: panelUsers.lastSignedIn }).from(panelUsers).orderBy(desc(panelUsers.createdAt)); }
export async function createPanelUser(input: { username: string; password: string; displayName: string; permissions: string[]; active: number }) { const db = await getDb(); if (!db) return { id: Date.now(), username: input.username, displayName: input.displayName, permissions: input.permissions, active: input.active, forcePasswordChange: 1 }; const result = await db.insert(panelUsers).values({ username: input.username, passwordHash: hashPanelPassword(input.password), displayName: input.displayName, permissions: serializePanelPermissions(input.permissions), active: input.active, forcePasswordChange: 1 }); return { id: Number(result[0].insertId), username: input.username, displayName: input.displayName, permissions: input.permissions, active: input.active, forcePasswordChange: 1 }; }
export async function updatePanelUser(id: number, input: { password?: string; displayName: string; permissions: string[]; active: number }) { const db = await getDb(); if (!db) return { id, ...input }; await db.update(panelUsers).set({ ...(input.password ? { passwordHash: hashPanelPassword(input.password), forcePasswordChange: 0 } : {}), displayName: input.displayName, permissions: serializePanelPermissions(input.permissions), active: input.active }).where(eq(panelUsers.id, id)); return { success: true } as const; }
export async function changePanelPassword(id: number, password: string) { const db = await getDb(); if (db) await db.update(panelUsers).set({ passwordHash: hashPanelPassword(password), forcePasswordChange: 0 }).where(eq(panelUsers.id, id)); return { success: true } as const; }
export async function addPanelActivity(input: { panelUserId?: number | null; actorLabel: string; action: string; entityType: string; entityId?: number | null; summary: string }) { const db = await getDb(); if (db) await db.insert(panelActivityLogs).values(input); return { success: true } as const; }
export async function getPanelActivity(limit = 100) { const db = await getDb(); if (!db) return []; return db.select().from(panelActivityLogs).orderBy(desc(panelActivityLogs.createdAt)).limit(limit); }

export async function recordPageView(input: { path: string; referrer?: string | null; source: string; device: string }) { const db = await getDb(); if (db) await db.insert(pageViewEvents).values(input); return { success: true } as const; }
export async function getAnalyticsSummary(days = 30) {
  const db = await getDb();
  if (!db) return { totalViews: 0, uniqueDays: 0, googleViews: 0, topPages: [], sources: [] };
  const since = new Date(Date.now() - days * 86400000);
  const rows = await db.select().from(pageViewEvents);
  const recent = rows.filter(row => row.createdAt >= since);
  const count = (items: typeof recent) => { const map = new Map<string, number>(); items.forEach(item => map.set(item.source, (map.get(item.source) ?? 0) + 1)); return Array.from(map.entries()).map(([name, value]) => ({ name, value })).sort((a,b) => b.value-a.value); };
  const pages = new Map<string, number>(); recent.forEach(row => pages.set(row.path, (pages.get(row.path) ?? 0) + 1));
  return { totalViews: recent.length, uniqueDays: new Set(recent.map(row => row.createdAt.toISOString().slice(0, 10))).size, googleViews: recent.filter(row => row.source === "google").length, topPages: Array.from(pages.entries()).map(([path, views]) => ({ path, views })).sort((a,b) => b.views-a.views).slice(0, 5), sources: count(recent) };
}
export async function deletePanelUser(id: number) { const db = await getDb(); if (db) { await db.delete(panelSessions).where(eq(panelSessions.panelUserId, id)); await db.delete(panelUsers).where(eq(panelUsers.id, id)); } return { success: true } as const; }

export async function getSiteContent() {
  const db = await getDb();
  if (!db) return FALLBACK_CONTENT;
  const rows = await db.select().from(siteContent).where(eq(siteContent.id, 1)).limit(1);
  return rows[0] ?? FALLBACK_CONTENT;
}

export async function updateSiteContent(input: Omit<InsertSiteContent, "id" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { ...FALLBACK_CONTENT, ...input, updatedAt: new Date() };
  await db.insert(siteContent).values({ id: 1, ...input }).onDuplicateKeyUpdate({ set: input });
  return getSiteContent();
}

export async function getGalleryImages() {
  const db = await getDb();
  if (!db) return FALLBACK_GALLERY;
  const rows = await db.select().from(galleryImages).orderBy(desc(galleryImages.createdAt));
  return rows.length ? rows : FALLBACK_GALLERY;
}

export async function insertGalleryImage(input: Omit<InsertGalleryImage, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) return { id: Date.now(), ...input, createdAt: new Date() };
  const result = await db.insert(galleryImages).values(input);
  return { id: Number(result[0].insertId), ...input, createdAt: new Date() };
}

export async function deleteGalleryImage(id: number) {
  const db = await getDb();
  if (!db) return { success: true };
  await db.delete(galleryImages).where(eq(galleryImages.id, id));
  return { success: true };
}

export async function getTimetableEntries(entityType?: "branch" | "coach", entityId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (entityType && entityId) {
    return db.select().from(timetableEntries)
      .where(and(eq(timetableEntries.entityType, entityType), eq(timetableEntries.entityId, entityId)))
      .orderBy(timetableEntries.sortOrder, timetableEntries.time);
  }
  return db.select().from(timetableEntries).orderBy(timetableEntries.entityType, timetableEntries.entityId, timetableEntries.sortOrder);
}

export async function replaceTimetableEntries(entityType: "branch" | "coach", entityId: number, entries: Omit<InsertTimetableEntry, "id" | "entityType" | "entityId" | "updatedAt">[]) {
  const db = await getDb();
  if (!db) return entries.map((entry, index) => ({ ...entry, id: index + 1, entityType, entityId, updatedAt: new Date() }));
  await db.delete(timetableEntries).where(and(eq(timetableEntries.entityType, entityType), eq(timetableEntries.entityId, entityId)));
  if (entries.length) await db.insert(timetableEntries).values(entries.map((entry, index) => ({ ...entry, entityType, entityId, sortOrder: entry.sortOrder ?? index })));
  return getTimetableEntries(entityType, entityId);
}

export async function getBlogArticles(publishedOnly = true) {
  const db = await getDb();
  if (!db) return publishedOnly ? FALLBACK_ARTICLES.filter(article => article.published === 1) : [];
  const query = db.select().from(blogArticles).orderBy(desc(blogArticles.publishedAt));
  const rows = await query;
  const filtered = publishedOnly ? rows.filter(article => article.published === 1) : rows;
  return filtered.length ? filtered : (publishedOnly ? FALLBACK_ARTICLES : []);
}

export async function insertBlogArticle(input: Omit<InsertBlogArticle, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id: Date.now(), ...input, createdAt: new Date(), updatedAt: new Date() };
  const result = await db.insert(blogArticles).values(input);
  return { id: Number(result[0].insertId), ...input, createdAt: new Date(), updatedAt: new Date() };
}

export async function updateBlogArticle(id: number, input: Omit<InsertBlogArticle, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id, ...input, createdAt: new Date(), updatedAt: new Date() };
  await db.update(blogArticles).set(input).where(eq(blogArticles.id, id));
  const rows = await db.select().from(blogArticles).where(eq(blogArticles.id, id)).limit(1);
  return rows[0];
}

export async function deleteBlogArticle(id: number) {
  const db = await getDb();
  if (db) await db.delete(blogArticles).where(eq(blogArticles.id, id));
  return { success: true } as const;
}

export async function getCoaches(publishedOnly = true) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(coaches).orderBy(coaches.sortOrder, desc(coaches.createdAt));
  return publishedOnly ? rows.filter(row => row.published === 1) : rows;
}

export async function insertCoach(input: Omit<InsertCoach, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id: Date.now(), ...input, createdAt: new Date(), updatedAt: new Date() };
  const result = await db.insert(coaches).values(input);
  return { id: Number(result[0].insertId), ...input, createdAt: new Date(), updatedAt: new Date() };
}

export async function updateCoach(id: number, input: Omit<InsertCoach, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id, ...input, createdAt: new Date(), updatedAt: new Date() };
  await db.update(coaches).set(input).where(eq(coaches.id, id));
  const rows = await db.select().from(coaches).where(eq(coaches.id, id)).limit(1);
  return rows[0];
}

export async function deleteCoach(id: number) {
  const db = await getDb();
  if (db) await db.delete(coaches).where(eq(coaches.id, id));
  return { success: true } as const;
}

export async function getBranches(publishedOnly = true) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(branches).orderBy(branches.sortOrder, desc(branches.createdAt));
  return publishedOnly ? rows.filter(row => row.published === 1) : rows;
}

export async function insertBranch(input: Omit<InsertBranch, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id: Date.now(), ...input, createdAt: new Date(), updatedAt: new Date() };
  const result = await db.insert(branches).values(input);
  return { id: Number(result[0].insertId), ...input, createdAt: new Date(), updatedAt: new Date() };
}

export async function updateBranch(id: number, input: Omit<InsertBranch, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return { id, ...input, createdAt: new Date(), updatedAt: new Date() };
  await db.update(branches).set(input).where(eq(branches.id, id));
  const rows = await db.select().from(branches).where(eq(branches.id, id)).limit(1);
  return rows[0];
}

export async function deleteBranch(id: number) {
  const db = await getDb();
  if (db) await db.delete(branches).where(eq(branches.id, id));
  return { success: true } as const;
}
