import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { PanelUser, User } from "../../drizzle/schema";
import { parse } from "cookie";
import { PANEL_SESSION_COOKIE } from "@shared/const";
import { getPanelUserBySessionToken } from "../db";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  panelUser: PanelUser | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let panelUser: PanelUser | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  try {
    const token = parse(opts.req.headers.cookie ?? "")[PANEL_SESSION_COOKIE];
    if (token) panelUser = (await getPanelUserBySessionToken(token)) ?? null;
  } catch {
    panelUser = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
    panelUser,
  };
}
