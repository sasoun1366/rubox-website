import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import path from "path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { sdk } from "./sdk";
import { storagePut } from "../storage";
import { addPanelActivity, getBlogArticles, getPanelUserBySessionToken, parsePanelPermissions, recordPageView } from "../db";
import { PANEL_SESSION_COOKIE } from "@shared/const";
import { parse } from "cookie";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => server.close(() => resolve(true)));
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) return port;
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // Keep crawler-facing files ahead of the SPA fallback so search engines receive
  // their real MIME types and contents instead of index.html.
  const publicRoot = process.env.NODE_ENV === "development"
    ? path.resolve(process.cwd(), "client/public")
    : path.resolve(process.cwd(), "dist/public");
  app.get("/robots.txt", (_req, res) => res.type("text/plain").sendFile(path.join(publicRoot, "robots.txt")));
  app.get("/sitemap.xml", async (_req, res) => {
    try {
      const articles = await getBlogArticles(true);
      const origin = "https://ruboxfit-n8vu83tm.manus.space";
      const articleUrls = articles.map(article => `\n  <url><loc>${origin}/blog/${article.slug}</loc><lastmod>${new Date(article.updatedAt).toISOString().slice(0, 10)}</lastmod><changefreq>monthly</changefreq><priority>0.7</priority></url>`).join("");
      return res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${origin}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>${articleUrls}\n</urlset>`);
    } catch {
      return res.type("application/xml").sendFile(path.join(publicRoot, "sitemap.xml"));
    }
  });
  app.get("/site.webmanifest", (_req, res) => res.type("application/manifest+json").sendFile(path.join(publicRoot, "site.webmanifest")));
  app.post("/api/analytics/pageview", async (req, res) => {
    try {
      const { path: pagePath, referrer } = req.body as { path?: string; referrer?: string };
      if (!pagePath || pagePath.length > 255) return res.status(400).json({ message: "Invalid page path" });
      const ref = referrer || "";
      const source = /google\./i.test(ref) ? "google" : /instagram\.com|t\.me/i.test(ref) ? "social" : ref ? "referral" : "direct";
      const device = /mobile|android|iphone/i.test(req.headers["user-agent"] || "") ? "mobile" : "desktop";
      await recordPageView({ path: pagePath, referrer: ref.slice(0, 1000), source, device });
      return res.status(204).end();
    } catch { return res.status(204).end(); }
  });

  app.post("/api/admin/upload", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const panelToken = parse(req.headers.cookie ?? "")[PANEL_SESSION_COOKIE];
      const panelUser = panelToken ? await getPanelUserBySessionToken(panelToken) : null;
      const panelCanUpload = panelUser && parsePanelPermissions(panelUser.permissions).some(permission => ["content", "media", "blog", "coaches", "branches"].includes(permission));
      if ((!user || user.role !== "admin") && !panelCanUpload) return res.status(403).json({ message: "Admin access required" });
      const { fileName, contentType, data } = req.body as { fileName?: string; contentType?: string; data?: string };
      if (!data || !contentType?.startsWith("image/")) return res.status(400).json({ message: "A valid image is required" });
      const raw = data.includes(",") ? data.split(",")[1] : data;
      const buffer = Buffer.from(raw, "base64");
      if (buffer.byteLength > 15 * 1024 * 1024) return res.status(413).json({ message: "Image must be smaller than 15MB" });
      const safeName = (fileName || "rubox-image.jpg").replace(/[^a-zA-Z0-9._-]/g, "-");
      const result = await storagePut(`rubox-gallery/${Date.now()}-${safeName}`, buffer, contentType);
      await addPanelActivity({ panelUserId: panelUser?.id ?? null, actorLabel: panelUser?.displayName || user?.name || "مالک پروژه", action: "created", entityType: "media", summary: `تصویر ${safeName} آپلود شد.` });
      return res.json(result);
    } catch (error) {
      console.error("[Admin upload] failed", error);
      return res.status(500).json({ message: "Upload failed" });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({ router: appRouter, createContext })
  );
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  server.listen(port, () => console.log(`Server running on http://localhost:${port}/`));
}

startServer().catch(console.error);
