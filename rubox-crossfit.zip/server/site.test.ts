import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(user: TrpcContext["user"] = null, panelUser: TrpcContext["panelUser"] = null): TrpcContext {
  return {
    user,
    panelUser,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("site content", () => {
  it("exposes public content and gallery data without authentication", async () => {
    const caller = appRouter.createCaller(context());
    const content = await caller.site.content();
    const gallery = await caller.site.gallery();
    expect(content.heroTitleFa.length).toBeGreaterThan(0);
    expect(content.heroImageUrl.length).toBeGreaterThan(0);
    expect(gallery.length).toBeGreaterThan(0);
  });

  it("protects content updates for admins", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.site.updateContent({
      heroTitleFa: "عنوان",
      heroTitleEn: "Title",
      heroTextFa: "توضیح",
      heroTextEn: "Description",
      heroImageUrl: "/image.jpg",
      heroImageKey: null,
      ctaLabelFa: "شروع",
      ctaLabelEn: "Start",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("enforces granular panel permissions on protected reads", async () => {
    const panelUser = { id: 1, username: "reception", passwordHash: "", displayName: "پذیرش", permissions: '["timetable"]', active: 1, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: null };
    const caller = appRouter.createCaller(context(null, panelUser));
    expect(Array.isArray(await caller.site.managedTimetable())).toBe(true);
    await expect(caller.site.managedContent()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("exposes timetable data publicly and protects timetable updates", async () => {
    const caller = appRouter.createCaller(context());
    const entries = await caller.site.timetable();
    expect(Array.isArray(entries)).toBe(true);
    await expect(caller.site.updateTimetable({
      entityType: "branch",
      entityId: 1,
      entries: [{ dayFa: "شنبه", dayEn: "Saturday", time: "۰۷:۰۰", titleFa: "کلاس", titleEn: "Class", sortOrder: 0 }],
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("exposes published articles publicly and protects article publishing", async () => {
    const caller = appRouter.createCaller(context());
    const articles = await caller.site.blog.list({ publishedOnly: true });
    expect(articles.length).toBeGreaterThan(0);
    expect(articles[0]?.slug).toBeTruthy();
    const managementArticles = await caller.site.blog.list({ publishedOnly: false });
    expect(managementArticles.length).toBeGreaterThanOrEqual(articles.length);
    await expect(caller.site.blog.create({
      slug: "test-article",
      titleFa: "مقاله تست",
      titleEn: "Test article",
      excerptFa: "خلاصه",
      excerptEn: "Summary",
      bodyFa: "متن",
      bodyEn: "Body",
      category: "Test",
      readTime: 3,
      coverImageUrl: null,
      published: 1,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("exposes roster data publicly and protects roster management", async () => {
    const caller = appRouter.createCaller(context());
    expect(Array.isArray(await caller.site.coaches.list({ publishedOnly: true }))).toBe(true);
    expect(Array.isArray(await caller.site.branches.list({ publishedOnly: true }))).toBe(true);
    await expect(caller.site.coaches.create({
      nameFa: "مربی تست", nameEn: "Test Coach", roleFa: "قدرت", roleEn: "Strength", bioFa: "رزومه", bioEn: "Bio", experience: "1 سال",
      classesFa: "کلاس", classesEn: "Class", diagramFa: "دیاگرام", diagramEn: "Diagram", imageUrl: null, imageKey: null, published: 1, sortOrder: 0,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.site.branches.create({
      nameFa: "شعبه تست", nameEn: "Test Branch", addressFa: "آدرس", addressEn: "Address", phone: "000", tagFa: "تست", tagEn: "Test",
      mapsUrl: null, descriptionFa: "توضیح", descriptionEn: "Description", imageUrl: null, imageKey: null, published: 1, sortOrder: 0,
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("protects SEO analytics and AI suggestions behind panel permissions", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.panelAuth.analytics({ days: 30 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.site.blog.suggestSeo({ titleFa: "کراس‌فیت در تهران", titleEn: "CrossFit in Tehran", excerptFa: "خلاصه", bodyFa: "متن", category: "آموزش" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
