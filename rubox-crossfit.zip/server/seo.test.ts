import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");

function readProjectFile(relativePath: string) {
  return readFileSync(resolve(projectRoot, relativePath), "utf8");
}

describe("technical SEO assets", () => {
  it("publishes crawler directives and a canonical sitemap", () => {
    const robots = readProjectFile("client/public/robots.txt");
    const sitemap = readProjectFile("client/public/sitemap.xml");

    expect(robots).toContain("Allow: /");
    expect(robots).toContain("Disallow: /admin");
    expect(robots).toContain("Sitemap: https://ruboxfit-n8vu83tm.manus.space/sitemap.xml");
    expect(sitemap).toContain("<urlset");
    expect(sitemap).toContain("https://ruboxfit-n8vu83tm.manus.space/");
    expect(sitemap).toContain("/blog/crossfit-for-beginners");
  });

  it("includes canonical, social metadata, schema and web manifest", () => {
    const html = readProjectFile("client/index.html");
    const schemaJson = html.match(/<script type="application\/ld\+json">\s*([\s\S]*?)\s*<\/script>/)?.[1];

    expect(html).toContain('rel="canonical"');
    expect(html).toContain('property="og:title"');
    expect(html).toContain('application/ld+json');
    expect(html).toContain('"SportsActivityLocation"');
    expect(html).toContain('https://instagram.com/rowbox2023');
    expect(html).toContain('https://t.me/Rowbox2023');
    expect(html).toContain('"Blog"');
    expect(html).toContain('rel="manifest"');
    expect(html).toContain('name="geo.region"');
    expect(html).toContain('name="googlebot"');
    expect(html).toContain('property="og:image:width"');
    expect(schemaJson).toBeTruthy();
    expect(() => JSON.parse(schemaJson!)).not.toThrow();
  });

  it("uses optimized WebP media and a lighter video source", () => {
    const home = readProjectFile("client/src/pages/Home.tsx");

    expect(home).toContain("rowbox-hero-lite_a97b0546.webm");
    expect(home).toContain("rubox-hero_93a391b2.webp");
    expect(home).not.toContain("gym-tour-3510_df630df2.jpg");
  });

  it("adds route-aware metadata for article pages", () => {
    const article = readProjectFile("client/src/pages/BlogArticle.tsx");
    expect(article).toContain('link[rel="canonical"]');
    expect(article).toContain('meta[property="og:title"]');
    expect(article).toContain('document.title = `${title} | مجله روباکس`');
    expect(article).toContain('"@type": "Article"');
  });
});
