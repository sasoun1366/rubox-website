import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME, PANEL_SESSION_COOKIE } from "@shared/const";
import { parse } from "cookie";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, panelPermissionProcedure, publicProcedure, router } from "./_core/trpc";
import {
  deleteGalleryImage,
  getGalleryImages,
  getSiteContent,
  insertGalleryImage,
  updateSiteContent,
  getTimetableEntries,
  replaceTimetableEntries,
  getBlogArticles,
  insertBlogArticle,
  updateBlogArticle,
  deleteBlogArticle,
  getCoaches, insertCoach, updateCoach, deleteCoach,
  getBranches, insertBranch, updateBranch, deleteBranch,
  getPanelUserByUsername, verifyPanelPassword, createPanelSession, deletePanelSession, parsePanelPermissions, getPanelUsers, createPanelUser, updatePanelUser, deletePanelUser, changePanelPassword, addPanelActivity, getPanelActivity,
  recordPageView, getAnalyticsSummary,
} from "./db";
import { invokeLLM } from "./_core/llm";

const contentInput = z.object({
  heroTitleFa: z.string().min(1),
  heroTitleEn: z.string().min(1),
  heroTextFa: z.string().min(1),
  heroTextEn: z.string().min(1),
  heroImageUrl: z.string().min(1),
  heroImageKey: z.string().optional().nullable(),
  ctaLabelFa: z.string().min(1),
  ctaLabelEn: z.string().min(1),
});

const timetableEntry = z.object({
  dayFa: z.string().min(1),
  dayEn: z.string().min(1),
  time: z.string().min(1),
  titleFa: z.string().min(1),
  titleEn: z.string().min(1),
  sortOrder: z.number().int().min(0),
});

const blogArticleInput = z.object({
  slug: z.string().min(3).regex(/^[a-z0-9-]+$/),
  titleFa: z.string().min(1),
  titleEn: z.string().min(1),
  excerptFa: z.string().min(1),
  excerptEn: z.string().min(1),
  metaTitleFa: z.string().optional().nullable(),
  metaDescriptionFa: z.string().optional().nullable(),
  keywordsFa: z.string().optional().nullable(),
  keywordsEn: z.string().optional().nullable(),
  bodyFa: z.string().min(1),
  bodyEn: z.string().min(1),
  category: z.string().min(1),
  readTime: z.number().int().min(1).max(120),
  coverImageUrl: z.string().startsWith("/").or(z.string().url()).optional().nullable(),
  published: z.number().int().min(0).max(1),
  publishedAt: z.coerce.date().optional(),
});

const coachInput = z.object({
  nameFa: z.string().min(1), nameEn: z.string().min(1), roleFa: z.string().min(1), roleEn: z.string().min(1),
  bioFa: z.string().min(1), bioEn: z.string().min(1), experience: z.string().min(1), classesFa: z.string().min(1), classesEn: z.string().min(1),
  diagramFa: z.string().min(1), diagramEn: z.string().min(1), imageUrl: z.string().startsWith("/").or(z.string().url()).optional().nullable(), imageKey: z.string().optional().nullable(),
  published: z.number().int().min(0).max(1), sortOrder: z.number().int().min(0),
});
const branchInput = z.object({
  nameFa: z.string().min(1), nameEn: z.string().min(1), addressFa: z.string().min(1), addressEn: z.string().min(1), phone: z.string().min(1),
  tagFa: z.string().min(1), tagEn: z.string().min(1), mapsUrl: z.string().url().optional().nullable(), descriptionFa: z.string().min(1), descriptionEn: z.string().min(1),
  imageUrl: z.string().startsWith("/").or(z.string().url()).optional().nullable(), imageKey: z.string().optional().nullable(), published: z.number().int().min(0).max(1), sortOrder: z.number().int().min(0),
});

async function audit(ctx: { user: any; panelUser: any }, action: string, entityType: string, summary: string, entityId?: number) {
  const actor = ctx.panelUser ? ctx.panelUser.displayName : (ctx.user?.name || "مالک پروژه");
  await addPanelActivity({ panelUserId: ctx.panelUser?.id ?? null, actorLabel: actor, action, entityType, entityId: entityId ?? null, summary });
}

export const appRouter = router({
  system: systemRouter,
  panelAuth: router({
    me: publicProcedure.query(({ ctx }) => ctx.panelUser ? { id: ctx.panelUser.id, username: ctx.panelUser.username, displayName: ctx.panelUser.displayName, active: ctx.panelUser.active, forcePasswordChange: ctx.panelUser.forcePasswordChange === 1, permissions: parsePanelPermissions(ctx.panelUser.permissions) } : null),
    login: publicProcedure.input(z.object({ username: z.string().min(1), password: z.string().min(1) })).mutation(async ({ input, ctx }) => { const user = await getPanelUserByUsername(input.username); if (!user || !user.active || !verifyPanelPassword(input.password, user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "نام کاربری یا رمز عبور نادرست است." }); const token = await createPanelSession(user.id); ctx.res.cookie(PANEL_SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: ctx.req.protocol === "https", path: "/", maxAge: 1000 * 60 * 60 * 24 * 30 }); return { id: user.id, username: user.username, displayName: user.displayName, forcePasswordChange: user.forcePasswordChange === 1, permissions: parsePanelPermissions(user.permissions) }; }),
    logout: publicProcedure.mutation(async ({ ctx }) => { const token = parse(ctx.req.headers.cookie ?? "")[PANEL_SESSION_COOKIE]; if (token) await deletePanelSession(token); ctx.res.clearCookie(PANEL_SESSION_COOKIE, { httpOnly: true, sameSite: "lax", secure: ctx.req.protocol === "https", path: "/" }); return { success: true }; }),
    changePassword: publicProcedure.input(z.object({ currentPassword: z.string().min(1), newPassword: z.string().min(8) })).mutation(async ({ input, ctx }) => { if (!ctx.panelUser || !verifyPanelPassword(input.currentPassword, ctx.panelUser.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "رمز فعلی صحیح نیست." }); await changePanelPassword(ctx.panelUser.id, input.newPassword); await audit(ctx, "password_changed", "panel_user", "رمز عبور تغییر کرد.", ctx.panelUser.id); return { success: true } as const; }),
    users: router({
      list: adminProcedure.query(() => getPanelUsers()),
      create: adminProcedure.input(z.object({ username: z.string().min(3).max(80).regex(/^[a-zA-Z0-9._-]+$/), password: z.string().min(8), displayName: z.string().min(1), permissions: z.array(z.string()), active: z.number().int().min(0).max(1) })).mutation(async ({ input, ctx }) => { const result = await createPanelUser(input); await audit(ctx, "created", "panel_user", `کاربر ${input.displayName} ساخته شد.`); return result; }),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), password: z.string().min(8).optional(), displayName: z.string().min(1), permissions: z.array(z.string()), active: z.number().int().min(0).max(1) })).mutation(async ({ input, ctx }) => { const result = await updatePanelUser(input.id, input); await audit(ctx, "updated", "panel_user", `دسترسی‌های ${input.displayName} ویرایش شد.`, input.id); return result; }),
      remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deletePanelUser(input.id); await audit(ctx, "deleted", "panel_user", `کاربر پنل شماره ${input.id} حذف شد.`, input.id); return result; }),
    }),
    activity: adminProcedure.input(z.object({ limit: z.number().int().min(1).max(200).optional() }).optional()).query(({ input }) => getPanelActivity(input?.limit ?? 100)),
    analytics: adminProcedure.input(z.object({ days: z.number().int().min(7).max(90).optional() }).optional()).query(({ input }) => getAnalyticsSummary(input?.days ?? 30)),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  site: router({
    content: publicProcedure.query(() => getSiteContent()),
    managedContent: panelPermissionProcedure("content").query(() => getSiteContent()),
    gallery: publicProcedure.query(() => getGalleryImages()),
    managedGallery: panelPermissionProcedure("media").query(() => getGalleryImages()),
    timetable: publicProcedure.input(z.object({ entityType: z.enum(["branch", "coach"]).optional(), entityId: z.number().int().positive().optional() }).optional()).query(({ input }) => getTimetableEntries(input?.entityType, input?.entityId)),
    managedTimetable: panelPermissionProcedure("timetable").input(z.object({ entityType: z.enum(["branch", "coach"]).optional(), entityId: z.number().int().positive().optional() }).optional()).query(({ input }) => getTimetableEntries(input?.entityType, input?.entityId)),
    coaches: router({
      list: publicProcedure.input(z.object({ publishedOnly: z.boolean().optional() }).optional()).query(({ input }) => getCoaches(input?.publishedOnly ?? true)),
      managementList: panelPermissionProcedure("coaches").query(() => getCoaches(false)),
      create: panelPermissionProcedure("coaches").input(coachInput).mutation(async ({ input, ctx }) => { const result = await insertCoach(input); await audit(ctx, "created", "coach", `مربی ${input.nameFa} اضافه شد.`); return result; }),
      update: panelPermissionProcedure("coaches").input(z.object({ id: z.number().int().positive(), data: coachInput })).mutation(async ({ input, ctx }) => { const result = await updateCoach(input.id, input.data); await audit(ctx, "updated", "coach", `پروفایل مربی ${input.data.nameFa} ویرایش شد.`, input.id); return result; }),
      remove: panelPermissionProcedure("coaches").input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deleteCoach(input.id); await audit(ctx, "deleted", "coach", `مربی شماره ${input.id} حذف شد.`, input.id); return result; }),
    }),
    branches: router({
      list: publicProcedure.input(z.object({ publishedOnly: z.boolean().optional() }).optional()).query(({ input }) => getBranches(input?.publishedOnly ?? true)),
      managementList: panelPermissionProcedure("branches").query(() => getBranches(false)),
      create: panelPermissionProcedure("branches").input(branchInput).mutation(async ({ input, ctx }) => { const result = await insertBranch(input); await audit(ctx, "created", "branch", `شعبه ${input.nameFa} اضافه شد.`); return result; }),
      update: panelPermissionProcedure("branches").input(z.object({ id: z.number().int().positive(), data: branchInput })).mutation(async ({ input, ctx }) => { const result = await updateBranch(input.id, input.data); await audit(ctx, "updated", "branch", `مشخصات شعبه ${input.data.nameFa} ویرایش شد.`, input.id); return result; }),
      remove: panelPermissionProcedure("branches").input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deleteBranch(input.id); await audit(ctx, "deleted", "branch", `شعبه شماره ${input.id} حذف شد.`, input.id); return result; }),
    }),
    updateContent: panelPermissionProcedure("content").input(contentInput).mutation(async ({ input, ctx }) => { const result = await updateSiteContent(input); await audit(ctx, "updated", "site_content", "محتوای هدر سایت ویرایش شد."); return result; }),
    updateTimetable: panelPermissionProcedure("timetable").input(z.object({ entityType: z.enum(["branch", "coach"]), entityId: z.number().int().positive(), entries: z.array(timetableEntry).max(100) })).mutation(async ({ input, ctx }) => { const result = await replaceTimetableEntries(input.entityType, input.entityId, input.entries); await audit(ctx, "updated", "timetable", `تایم‌تیبل ${input.entityType === "branch" ? "شعبه" : "مربی"} ویرایش شد.`, input.entityId); return result; }),
    blog: router({
      list: publicProcedure.input(z.object({ publishedOnly: z.boolean().optional() }).optional()).query(({ input }) => getBlogArticles(input?.publishedOnly ?? true)),
      managementList: panelPermissionProcedure("blog").query(() => getBlogArticles(false)),
      create: panelPermissionProcedure("blog").input(blogArticleInput).mutation(async ({ input, ctx }) => { const result = await insertBlogArticle(input); await audit(ctx, "created", "article", `مقاله ${input.titleFa} منتشر شد.`); return result; }),
      update: panelPermissionProcedure("blog").input(z.object({ id: z.number().int().positive(), data: blogArticleInput })).mutation(async ({ input, ctx }) => { const result = await updateBlogArticle(input.id, input.data); await audit(ctx, "updated", "article", `مقاله ${input.data.titleFa} ویرایش شد.`, input.id); return result; }),
      remove: panelPermissionProcedure("blog").input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deleteBlogArticle(input.id); await audit(ctx, "deleted", "article", `مقاله شماره ${input.id} حذف شد.`, input.id); return result; }),
      suggestSeo: panelPermissionProcedure("blog").input(z.object({ titleFa: z.string().min(1), titleEn: z.string().min(1), excerptFa: z.string().optional().default(""), bodyFa: z.string().optional().default(""), category: z.string().optional().default("کراس‌فیت") })).mutation(async ({ input }) => {
        const response = await invokeLLM({ model: "gpt-5-mini", messages: [{ role: "system", content: "تو متخصص SEO محلی برای باشگاه کراس‌فیت ROWBOX در تهران هستی. فقط JSON معتبر برگردان." }, { role: "user", content: `برای این مقاله پیشنهاد SEO بساز:\nعنوان فارسی: ${input.titleFa}\nعنوان انگلیسی: ${input.titleEn}\nدسته: ${input.category}\nخلاصه: ${input.excerptFa}\nمتن: ${input.bodyFa.slice(0, 4000)}` }], response_format: { type: "json_schema", json_schema: { name: "seo_suggestion", strict: true, schema: { type: "object", properties: { keywordsFa: { type: "array", items: { type: "string" } }, keywordsEn: { type: "array", items: { type: "string" } }, metaTitleFa: { type: "string" }, metaDescriptionFa: { type: "string" }, slugSuggestion: { type: "string" }, faqQuestions: { type: "array", items: { type: "string" } } }, required: ["keywordsFa", "keywordsEn", "metaTitleFa", "metaDescriptionFa", "slugSuggestion", "faqQuestions"], additionalProperties: false } } }, maxTokens: 1200 });
        const content = response.choices[0]?.message.content; return JSON.parse(typeof content === "string" ? content : "{}");
      }),
    }),
    addGalleryImage: panelPermissionProcedure("media")
      .input(z.object({ titleFa: z.string().min(1), titleEn: z.string().min(1), url: z.string().url().or(z.string().startsWith("/")), fileKey: z.string().optional().nullable() }))
      .mutation(async ({ input, ctx }) => { const result = await insertGalleryImage(input); await audit(ctx, "created", "media", `تصویر ${input.titleFa} اضافه شد.`); return result; }),
    removeGalleryImage: panelPermissionProcedure("media").input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deleteGalleryImage(input.id); await audit(ctx, "deleted", "media", `تصویر شماره ${input.id} حذف شد.`, input.id); return result; }),
  }),
});

export type AppRouter = typeof appRouter;
