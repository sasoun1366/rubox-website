<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$action = isset($_GET['action']) ? $_GET['action'] : '';
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}

$coachesFile = $dataDir . '/coaches.json';
$branchesFile = $dataDir . '/branches.json';
$contentFile = $dataDir . '/content.json';
$timetableFile = $dataDir . '/timetable.json';

// Initialize default data if not exists
if (!file_exists($coachesFile)) {
    $defaultCoaches = [
        [
            "id" => 1,
            "slug" => "elyar-amirfatahi",
            "nameFa" => "الیار امیرفتحی",
            "nameEn" => "Elyar Amirfatahi",
            "birthDate" => "۱۳۶۸/۰۲/۱۶",
            "roleFa" => "عملکرد ورزشی و کراس‌فیت",
            "roleEn" => "Athletic Performance & CrossFit",
            "experience" => "۸+ سال",
            "coachingHistory" => "فعالیت حرفه‌ای در حوزه مربیگری از سال ۱۳۹۵\nسابقه مربیگری در باشگاه‌های بدنسازی، مجموعه‌های تمرینی خصوصی و جلسات اختصاصی\nمربی مجموعه ROWBOX از سال ۱۴۰۲ تاکنون",
            "certifications" => "مربیگری درجه ۳ بدنسازی\nمربیگری وزنه‌برداری از فدراسیون وزنه برداری\nCrossFit Programming Course\nCrossFit Fundamentals Course",
            "competitionsDomestic" => "Kish island games\nCBC\nHyroFit",
            "competitionsInternational" => "Vcity turkey\nBattle of Anatolia\nVarna Throwdown – Bulgaria",
            "bioFa" => "برنامه‌ریزی عملکردی برای ورزشکارانی که هدف بزرگ‌تری دارند. تمرکز بر وزنه‌برداری المپیکی، کراس‌فیت رقابتی و آمادگی کامل بدنی.",
            "bioEn" => "Performance programming for athletes with bigger goals.",
            "classesFa" => "Olympic Lifting\nPerformance CrossFit\nWOD Team",
            "classesEn" => "Olympic Lifting\nPerformance CrossFit\nWOD Team",
            "imageUrl" => "/pilot/uploads/1791014722385-8541d1c1.PNG",
            "published" => 1,
            "sortOrder" => 1
        ],
        [
            "id" => 2,
            "slug" => "hamid-yal",
            "nameFa" => "حمید یل",
            "nameEn" => "Hamid Yal",
            "birthDate" => "",
            "roleFa" => "قدرت و تکنیک",
            "roleEn" => "Strength & technique",
            "experience" => "۱۲+ سال",
            "coachingHistory" => "مربی قدرت و تکنیک با تمرکز بر ساختن پایه‌ای محکم برای هر ورزشکار.",
            "certifications" => "مربیگری تخصصی بدنسازی و وزنه‌برداری",
            "competitionsDomestic" => "",
            "competitionsInternational" => "",
            "bioFa" => "مربی قدرت و تکنیک با تمرکز بر ساختن پایه‌ای محکم برای هر ورزشکار.",
            "bioEn" => "Strength and technique coach focused on building a strong foundation for every athlete.",
            "classesFa" => "Strength Lab\nCrossFit Basics",
            "classesEn" => "Strength Lab\nCrossFit Basics",
            "imageUrl" => "/pilot/uploads/1791014833183-c4413866.JPG",
            "published" => 1,
            "sortOrder" => 2
        ],
        [
            "id" => 3,
            "slug" => "pouria-mohammadi",
            "nameFa" => "پوریا محمدی",
            "nameEn" => "Pouria Mohammadi",
            "birthDate" => "",
            "roleFa" => "کراس‌فیت پیشرفته",
            "roleEn" => "Advanced CrossFit",
            "experience" => "۱۰+ سال",
            "coachingHistory" => "مربی کراس‌فیت پیشرفته برای ورزشکارانی که دنبال رکورد بعدی هستند.",
            "certifications" => "مدارک بین‌المللی کراس‌فیت",
            "competitionsDomestic" => "",
            "competitionsInternational" => "",
            "bioFa" => "مربی کراس‌فیت پیشرفته برای ورزشکارانی که دنبال رکورد بعدی هستند.",
            "bioEn" => "Advanced CrossFit coach for athletes chasing their next personal best.",
            "classesFa" => "CrossFit Level 2\nWOD Team",
            "classesEn" => "CrossFit Level 2\nWOD Team",
            "imageUrl" => "/pilot/uploads/1791017210246-422353a9.JPG",
            "published" => 1,
            "sortOrder" => 3
        ]
    ];
    file_put_contents($coachesFile, json_encode($defaultCoaches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

if (!file_exists($branchesFile)) {
    $defaultBranches = [
        [
            "id" => 1,
            "nameFa" => "شعبه فرشته",
            "nameEn" => "Fereshteh Branch",
            "addressFa" => "تهران، خیابان فرشته، خیابان مریم غربی، پلاک ۲۴",
            "addressEn" => "No. 24, West Maryam St, Fereshteh St, Tehran",
            "phone" => "۰۲۱-۲۲۰۱۸۹۳۴",
            "tagFa" => "باشگاه مرکزی · مجهز به استخر و ریکاوری",
            "tagEn" => "HQ Flagship · Pool & Recovery",
            "mapsUrl" => "https://maps.google.com",
            "descriptionFa" => "باشگاه مرکزی روباکس با پیشرفته‌ترین تجهیزات کراس‌فیت و فضای تمرین سرپوشیده و روباز.",
            "descriptionEn" => "Rubox flagship facility with Olympic-standard equipment.",
            "imageUrl" => "/pilot/uploads/1791014833183-c4413866.JPG",
            "videoUrl" => "/videos/hero.mp4",
            "published" => 1
        ],
        [
            "id" => 2,
            "nameFa" => "شعبه نیاوران",
            "nameEn" => "Niavaran Branch",
            "addressFa" => "تهران، نیاوران، خیابان باهنر، مجتمع ورزشی روباکس",
            "addressEn" => "Bahonar St, Niavaran, Tehran",
            "phone" => "۰۲۱-۲۲۸۳۵۴۱۲",
            "tagFa" => "استودیو تمرینی تخصصی",
            "tagEn" => "Specialized Training Studio",
            "mapsUrl" => "https://maps.google.com",
            "descriptionFa" => "محیطی صمیمی و پرانرژی برای کلاس‌های گروهی و تمرینات استقامتی.",
            "descriptionEn" => "Energetic and community-centered training space.",
            "imageUrl" => "/pilot/uploads/1791017210246-422353a9.JPG",
            "videoUrl" => "/videos/hero.mp4",
            "published" => 1
        ],
        [
            "id" => 3,
            "nameFa" => "شعبه سعادت‌آباد",
            "nameEn" => "Saadat Abad Branch",
            "addressFa" => "تهران، سعادت‌آباد، میدان کاج، خیابان سرو غربی",
            "addressEn" => "Sarv West St, Kaj Sq, Saadat Abad, Tehran",
            "phone" => "۰۲۱-۲۲۳۸۷۱۶۵",
            "tagFa" => "تجهیزات مدرن کراس‌فیت",
            "tagEn" => "Modern CrossFit Facility",
            "mapsUrl" => "https://maps.google.com",
            "descriptionFa" => "شعبه غرب تهران با دسترسی عالی و سالن اختصاصی وزنه‌برداری قدرتی.",
            "descriptionEn" => "West Tehran branch with top-tier lifting zones.",
            "imageUrl" => "/pilot/uploads/1791014833183-c4413866.JPG",
            "videoUrl" => "/videos/hero.mp4",
            "published" => 1
        ]
    ];
    file_put_contents($branchesFile, json_encode($defaultBranches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Router
if ($action === 'coaches') {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        echo file_get_contents($coachesFile);
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $coaches = json_decode(file_get_contents($coachesFile), true) ?: [];
        $newId = count($coaches) ? max(array_column($coaches, 'id')) + 1 : 1;
        $input['id'] = $newId;
        if (empty($input['slug'])) {
            $input['slug'] = 'coach-' . $newId;
        }
        $coaches[] = $input;
        file_put_contents($coachesFile, json_encode($coaches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode($input);
        exit;
    }
}


if ($action === 'coaches_item') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $method = $_SERVER['REQUEST_METHOD'];
    $coaches = json_decode(file_get_contents($coachesFile), true) ?: [];

    if ($method === 'DELETE') {
        $filtered = array_values(array_filter($coaches, function($c) use ($id) { return $c['id'] !== $id; }));
        file_put_contents($coachesFile, json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(["success" => true]);
        exit;
    }

    if ($method === 'PUT' || $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        foreach ($coaches as $idx => $coach) {
            if ($coach['id'] === $id) {
                $coaches[$idx] = array_merge($coach, $input);
                file_put_contents($coachesFile, json_encode($coaches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                echo json_encode($coaches[$idx]);
                exit;
            }
        }
        echo json_encode(["success" => false, "message" => "Coach not found"]);
        exit;
    }
}

if ($action === 'branches_item') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $method = $_SERVER['REQUEST_METHOD'];
    $branches = json_decode(file_get_contents($branchesFile), true) ?: [];

    if ($method === 'DELETE') {
        $filtered = array_values(array_filter($branches, function($b) use ($id) { return $b['id'] !== $id; }));
        file_put_contents($branchesFile, json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(["success" => true]);
        exit;
    }

    if ($method === 'PUT' || $method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        foreach ($branches as $idx => $branch) {
            if ($branch['id'] === $id) {
                $branches[$idx] = array_merge($branch, $input);
                file_put_contents($branchesFile, json_encode($branches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                echo json_encode($branches[$idx]);
                exit;
            }
        }
        echo json_encode(["success" => false, "message" => "Branch not found"]);
        exit;
    }
}

if ($action === 'branches') {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        echo file_get_contents($branchesFile);
        exit;
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $branches = json_decode(file_get_contents($branchesFile), true) ?: [];
        $newId = count($branches) ? max(array_column($branches, 'id')) + 1 : 1;
        $input['id'] = $newId;
        $branches[] = $input;
        file_put_contents($branchesFile, json_encode($branches, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode($input);
        exit;
    }
}


if ($action === 'upload') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!empty($input['data'])) {
        $dataStr = $input['data'];
        if (strpos($dataStr, ',') !== false) {
            $dataStr = explode(',', $dataStr)[1];
        }
        $raw = base64_decode($dataStr);
        $uploadsDir = __DIR__ . '/uploads';
        if (!is_dir($uploadsDir)) {
            mkdir($uploadsDir, 0755, true);
        }
        $ext = pathinfo($input['fileName'] ?? 'photo.jpg', PATHINFO_EXTENSION) ?: 'jpg';
        $filename = time() . '-' . substr(md5(uniqid()), 0, 8) . '.' . $ext;
        file_put_contents($uploadsDir . '/' . $filename, $raw);
        echo json_encode(["url" => "/pilot/uploads/" . $filename, "key" => $filename]);
        exit;
    }
    echo json_encode(["error" => "No data provided"]);
    exit;
}


if ($action === "content") {
    if ($_SERVER["REQUEST_METHOD"] === "GET") {
        if (!file_exists($contentFile)) {
            $defaultContent = [
                "heroTitleFa" => "قدرتت را\nاز نو بساز.",
                "heroTitleEn" => "BUILD YOUR\nINNER FORCE.",
                "heroTextFa" => "کراس‌فیت برای آدم‌هایی که معمولی بودن را انتخاب نمی‌کنند.",
                "heroTextEn" => "CrossFit for people who refuse to settle for ordinary.",
                "ctaLabelFa" => "مشاهده شعب",
                "ctaLabelEn" => "Explore locations",
                "videoUrl" => "/videos/hero.mp4",
                "instagramUrl" => "https://instagram.com/rowbox2023",
                "telegramUrl" => "https://t.me/Rowbox2023",
                "contactPhone" => "۰۲۱-۲۲۰۱۸۹۳۴"
            ];
            file_put_contents($contentFile, json_encode($defaultContent, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        echo file_get_contents($contentFile);
        exit;
    }
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $input = json_decode(file_get_contents("php://input"), true);
        $curr = json_decode(file_get_contents($contentFile), true) ?: [];
        $updated = array_merge($curr, $input ?: []);
        file_put_contents($contentFile, json_encode($updated, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode($updated);
        exit;
    }
}

if ($action === "timetable") {
    if ($_SERVER["REQUEST_METHOD"] === "GET") {
        if (!file_exists($timetableFile)) {
            $fallback = __DIR__ . '/timetable-fallback.json';
            if (file_exists($fallback)) {
                copy($fallback, $timetableFile);
            }
        }
        if (file_exists($timetableFile)) {
            echo file_get_contents($timetableFile);
        } else {
            echo "[]";
        }
        exit;
    }
    if ($_SERVER["REQUEST_METHOD"] === "POST" || $_SERVER["REQUEST_METHOD"] === "PUT") {
        $input = json_decode(file_get_contents("php://input"), true);
        file_put_contents($timetableFile, json_encode($input ?: [], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        echo json_encode(["success" => true, "data" => $input]);
        exit;
    }
}


echo json_encode(["status" => "ok"]);
